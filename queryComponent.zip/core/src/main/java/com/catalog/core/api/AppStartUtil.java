package com.catalog.core.api;

import com.catalog.core.api.dto.AppInfoDTO;
import com.catalog.core.api.util.WebUtil;
import com.catalog.core.constant.WebConstants;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.springframework.core.env.Environment;

import java.util.Arrays;
import java.util.Collection;

/**
 * 
 */
public class AppStartUtil {

	public static void checkActiveProfiles(final Environment env, final Logger logger) {

		Collection<String> activeProfiles = Arrays.asList(env.getActiveProfiles());

		boolean isDevEnvironment = activeProfiles.contains(WebConstants.SPRING_PROFILE_DEVELOPMENT);
		boolean isStagingEnvironment = activeProfiles.contains(WebConstants.SPRING_PROFILE_STAGING);
		boolean isProdEnvironment = activeProfiles.contains(WebConstants.SPRING_PROFILE_PRODUCTION);

		boolean isCloudEnvironment = activeProfiles.contains(WebConstants.SPRING_PROFILE_CLOUD);

		int count = 0;

		if (isDevEnvironment) {
			count += 1;
		}

		if (isStagingEnvironment) {
			count += 1;
		}

		if (isProdEnvironment) {
			count += 1;
		}

		if (count > 1) {
			logger.error("You have misconfigured your application! Following profiles: "
					+ "'dev', 'staging' and 'prod' could NOT turn-on at the same time.");
		}

		if (isDevEnvironment && isCloudEnvironment) {
			logger.error("You have misconfigured your application! It should not "
					+ "run with both the 'dev' and 'cloud' profiles at the same time.");
		}

	}

	/**
	 * 
	 * @param env
	 */
	public static void logApplicationStartup(final Environment env, final Logger logger) {

		AppInfoDTO appInfo = WebUtil.getApplicationInfo(env);

		String[] activeProfiles = appInfo.getActiveProfiles();

		String applicationName = String.format("*  Application '%s' is running! Access URLs:",
				appInfo.getApplicationName());

		String localUrl = String.format("*  Local: \t%s", appInfo.getBaseUrl());
		String externalUrl = String.format("*  External: \t%s", appInfo.getBaseUrl());
		String activeProfilesLog = String.format("*  Profile(s): \t%s", String.join(", ", activeProfiles));

		int maxLength = 79;
		StringBuilder logMsg = new StringBuilder();

		logMsg.append("\n\n        " + StringUtils.rightPad("*", maxLength, "*") + "\n\t");

		logMsg.append(StringUtils.rightPad(applicationName, maxLength - 1, " ") + "*\n\t");

		logMsg.append(StringUtils.rightPad(localUrl, maxLength - 6, " ") + "*\n\t");

		logMsg.append(StringUtils.rightPad(externalUrl, maxLength - 3, " ") + "*\n\t");

		logMsg.append(StringUtils.rightPad(activeProfilesLog, maxLength - 1, " ") + "*\n\t");

		logMsg.append(StringUtils.rightPad("*", maxLength, "*") + "\n");

		if (activeProfiles != null && activeProfiles.length > 0) {
			for (String profile : activeProfiles) {
				if ("prod".equals(profile)) {
					logMsg.append("\n\n" + StringUtils.rightPad("*", maxLength, "*") + "\n\t");

					logMsg.append("${AnsiColor.RED}"
							+ StringUtils.rightPad("* !!!! YOU ARE DEPLOYING ON PRODUCTION.", maxLength, " ")
							+ "*\n\t");

					logMsg.append(StringUtils.rightPad("* MAKE SURE NOT TO MODIFY DATA BY ACCIDENT !!!!!!\\n\\t",
							maxLength, " ") + "*\n\t");

					logMsg.append(StringUtils.rightPad("*", maxLength, "*") + "\n");
				}
			}
		}

		logger.info(logMsg.toString());
	}

}
