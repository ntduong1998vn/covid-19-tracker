/**
 * Created by Bizhw & EPS.
 * User: ThaiHV
 */

package com.catalog.core.custom;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.deser.ContextualDeserializer;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/*
 * @Note:
 * Client sends request json {"date": "2019-01-25 05:05:05"}
 * ==Deserializer=>
 * Server receives Date (Fri Jan 25 05:05:05 ICT 2019)
 *
 * */

@Component
public class CustomDateDeserializer extends StdDeserializer<Date> implements ContextualDeserializer {

    private static final long serialVersionUID = 1L;
    private SimpleDateFormat formatter = new SimpleDateFormat();
    private JsonFormat jsonFormatAnnotation;

    public CustomDateDeserializer() {
        this(null);
    }

    public CustomDateDeserializer(Class vc) {
        super(vc);
    }

    @Override
    public JsonDeserializer<?> createContextual(DeserializationContext ctxt, BeanProperty property) throws JsonMappingException {
        // get field's pattern bases on @JsonFormat annotation
        this.jsonFormatAnnotation = property.getAnnotation(JsonFormat.class);
        return this;
    }

    @Override
    public Date deserialize(JsonParser jsonparser, DeserializationContext context)
            throws IOException {
        String date = jsonparser.getText();
        try {
            if (StringUtils.isNotBlank(date)) {
                formatter.applyPattern(jsonFormatAnnotation.pattern());
                return formatter.parse(date);
            }
            return null;
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }
    }
}