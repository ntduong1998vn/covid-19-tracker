package com.catalog.core.constant;

public class StaticEntityConst {

    public static final int PURCHASE_SYSTEM_TYPE = 1;
    public static final int CATALOG_KIND1 = 2;
    public static final int LINKAGE_ORDER_COMPANY = 3;
    public static final int CUSTOM_TABS = 4;
    public static final int TEMP_MAIL_TYPE = 5;
    public static final int TIME_CHANGE_PASSWORD = 6;
    public static final int PRODUCT_RANK = 7;
    public static final int GREEN_PRODUCT_TYPE = 8;
    public static final int PROGRAM_TYPE = 9;
    public static final int GREEN_PRODUCT_STANDARD = 10;
    public static final int HISTORY_TYPE = 11;
    public static final int DELIVERY_TYPE = 12;
    public static final int CATALOG_IDENTIFICATION = 13;
    public static final int PRODUCT_STATUS_CONFIRM = 14;
    public static final int HISTORY_SEARCH_ITEM = 15;
    public static final int TAX_CLASSIFY = 16;
    public static final int CATALOG_KIND2 = 17;
    public static final int COMPANY_NAME_TYPE = 18;
    public static final int PUNCHOUT_VERSION = 19;
    public static final int DISPLAY_EXTERNAL_CATALOG = 20;
    public static final int SORT_HISTORY_SEARCH_INFO = 21;
    public static final int QUANTITY_UNIT_CD = 22;
    public static final int EVA_OP = 23;
    public static final int CATALOG_SEARCH_METHOD = 24;
    public static final int COMPANY_DIVISION = 25;
    public static final int WK_APPLICANT_STATUS = 26;
    public static final int UISELECT_TYPE = 27;
    public static final int UISELECT = 28;
    public static final int PROGRAM = 29;
    public static final int COUNTRY = 30;
    public static final int ITEM_TYPE = 35;
    public static final int CURRENCY = 36;

    public static final int USER_ACTIVITY_TYPE = 31;
    public static final int CUSTOM_STYLE = 32;
    public static final int SITE_PROPERTIES_HAS_UPDATE = 33;
    public static final int STATUS_REJECT = 34;
    public static final String SORT_SUB_SCRIPTION_INFO_1_ID = "222";
    public static final String SORT_SUB_SCRIPTION_INFO_2_ID = "244";

    /********** UI select static ***********/
    public static final long V2_SORT_1 = 249;
    public static final long V2_SORT_2 = 251;
    public static final long V2_SORT_3 = 238;
    public static final long V2_SORT_4 = 255;
    public static final long V2_SORT_10 = 256;
    public static final long CM_SORT_1 = 241;
    public static final long CM_SORT_2 = 243;
    public static final long CM_SORT_3 = 257;
    public static final long CM_SORT_10 = 230;
    public static final long EVALUATION = 225;

    public static final String V2_SORT_1_LABEL = "すべて";
    public static final String V2_SORT_2_LABEL = "グリーン品";
    public static final String V2_SORT_3_LABEL = "優先カタログ";
    public static final String V2_SORT_4_LABEL = "推奨品";
    public static final String V2_SORT_10_LABEL = "スコア";

    /********** UI select type static ***********/
    public static final long HAS_NONE = 223;

    public static final String REASON_ORDER_REJECTION = "219";

    /********** Catalog method search static ***********/
    public static final Long CM_SEARCH_EXTERNAL_ONLY = 2L;

    /********** Wk Applicant Status ***********/
    public static final Long WK_APPLICANT_STATUS_WAIT_APPLICANT = 213L; // 申請待ち
    public static final Long WK_APPLICANT_STATUS_INTERNAL_REJECT = 211L; // 社内 差戻し
    public static final Long WK_APPLICANT_STATUS_EXTERNAL_REJECT = 207L; // お客様 差戻し
    public static final Long WK_APPLICANT_STATUS_WAIT_INTERNAL_APPROVE = 210L;
    public static final Long WK_APPLICANT_STATUS_WAIT_EXTERNAL_APPROVE_PRODUCT = 208L;
    public static final Long WK_APPLICANT_STATUS_WAIT_EXTERNAL_APPROVE_PRICE = 215L;
    public static final Long WK_APPLICANT_STATUS_REVOKE = 209L;
    public static final Long WK_APPLICANT_STATUS_FINISHED = 212L;
    public static final Long WK_APPLICANT_STATUS_PULLBACK = 214L;

    /********** User Role ***********/
    public static final String REGISTERED = "UR001_Registered";
    public static final String CATALOG_ADMIN = "UR002_CatalogAdmin";
    public static final String ORDER_MANAGER = "UR007_OrderManager";
    public static final String SEARCH_PRODUCT = "UR008_SearchProduct";
    public static final String MASTER_ADMIN = "UR004_MasterAdmin";
    public static final String COMPANY_GROUP_ADMIN = "UR006_CompanyGroupAdmin";
    public static final String CATALOG_APPROVAL = "UR003_CatalogApproval";
    public static final String CATALOG_PRODUCT_APPROVAL = "UR005_CatalogProductApproval";
    public static final String GROUP_CATALOG_ADMIN = "UR009_GroupCatalogAdmin";

    /********** BatchTask_Product ***********/
    public static final Long BATCH_TASK_PRODUCT_GET_TYPE_UPLOAD_PRODUCT = 1L;
    public static final Long BATCH_TASK_PRODUCT_GET_TYPE_UPLOAD_POSTAGE = 100L;
    public static final Long BATCH_TASK_PRODUCT_GET_TYPE_UPLOAD_IMAGE = 10L;

    /********** Catalog Kind 2 ***********/
    public static final Long CATALOG_KIND_2_EXTERNAL = 104L;
    public static final Long CATALOG_KIND_2_INTERNAL = 105L;

    /********** Company Division ***********/
    public static final long COMPANY_DIVISION_SB = 206;
    public static final long COMPANY_DIVISION_BUYER = 201;
    public static final long COMPANY_DIVISION_SUPPLIER = 205;
    public static final long COMPANY_DIVISION_DIRECT_SUPPLIER = 203;

    /********** Tax Classify ***********/
    public static final Long TAX_CLASSIFY_INCLUDING_TAX = 96L;
    public static final Long TAX_CLASSIFY_EXCLUDING_TAX = 97L;
    public static final Long TAX_CLASSIFY_TAX_FREE = 98L;
    public static final Long TAX_CLASSIFY_DUTY_FREE = 99L;
    public static final Long TAX_CLASSIFY_EXEMPT_CONSUMPTION_TAX = 100L;
    public static final Long TAX_CLASSIFY_NON_TAX = 101L;
    public static final Long TAX_CLASSIFY_REDUCED_INCLUDING_TAX = 102L;
    public static final Long TAX_CLASSIFY_REDUCED_EXCLUDING_TAX = 103L;

    /********** Item Type ***********/
    public static final Long ITEM_TYPE_EFFECTIVE = 295L;
    public static final Long ITEM_TYPE_DISCONTINUED = 294L;
    public static final Long ITEM_TYPE_SELL_DISCONTINUED = 293L;

    /********** Green Product Type ***********/
    public static final Long GREEN_TYPE_1 = 41L;
    public static final Long GREEN_TYPE_2 = 42L;
    public static final Long GREEN_TYPE_3 = 43L;
}
