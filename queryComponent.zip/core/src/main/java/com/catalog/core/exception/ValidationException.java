package com.catalog.core.exception;

import org.springframework.http.HttpStatus;

import java.util.Objects;

public class ValidationException extends BaseException {

	/**
	 *
	 */
	private static final long serialVersionUID = -1370831544013604322L;

	public ValidationException(String msg, String code) {
		super(msg, code);
	}

	public ValidationException(String msg) {
		super(msg, Objects.toString(HttpStatus.INTERNAL_SERVER_ERROR.value()));
	}
}
