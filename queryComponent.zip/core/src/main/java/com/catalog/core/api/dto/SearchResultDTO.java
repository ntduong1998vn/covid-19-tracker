package com.catalog.core.api.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.List;

/**
 * 
 * 
 * @param <DTO>
 */
@Getter
@Setter
public class SearchResultDTO<DTO> {

	/**
	 * 
	 */
	private List<DTO> results;

	/**
	 * 
	 */
	private PaginationInfoDTO paging;
	
}
