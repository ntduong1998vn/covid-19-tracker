package com.catalog.core.exception;

public class InvalidImportInputException extends BaseException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7307570212812106399L;

	public InvalidImportInputException(String message) {
		super(message, "");
	}
}
