package com.catalog.core.constant;

public class BatchTaskProductConst {
    public static final int UPLOAD_PRODUCT = 1;
    public static final int DOWNLOAD_PRODUCT = 2;
    public static final int DOWNLOAD_PRODUCT_SUPPLIER = 1;
    public static final int UPLOAD_IMAGE = 10;
    public static final int UPLOAD_POSTAGE = 100;
    public static final int UPLOAD_PRODUCT_2 = 1;
    public static final int UPLOAD_PUBLIC_SUPPLIER = 1000;
}
