/**
 * Created by Bizhw & EPS.
 * User: Tannv
 * Created: 2019/08/17
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class OrganizationUnitNameDto implements Serializable {


    /**
     * 原価センタ
     */
    @ExcelIndicator(excelPosition = 0)
    private String organizationCode;

    @ExcelIndicator(excelPosition = 1)
    private String languageCode;

    /**
     * 有効開始日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 2)
    private String effectiveStartDate;
    /**
     * 有効終了日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 3)
    private String effectiveEndDate;
    /**
     * 名称
     */
    @ExcelIndicator(excelPosition = 4)
    private String officialOrganizationName;

    @ExcelIndicator(excelPosition = 5)
    private String organizationName;

    @ExcelIndicator(excelPosition = 6)
    private String abbreviatedOrganizationName;


    @ExcelIndicator(excelPosition = 7)
    private String companyGroupDisplayCode;

}
