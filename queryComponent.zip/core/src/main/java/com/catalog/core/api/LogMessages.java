package com.catalog.core.api;

/**
 * This utility class will help keep messages consistent.
 *
 * @author
 */
public class LogMessages {

    /**
     *
     */
    private static final String START_REQUEST_LOG = "START http request: %s";

    /**
     *
     */
    private static final String FINISH_REQUEST_LOG = "END http request: %s";

    /**
     *
     */
    private static final String START_SERVICE_METHOD_LOG = "START service method: %s";

    /**
     *
     */
    private static final String FINISH_SERVICE_METHOD_LOG = "END service method: %s";

    /**
     *
     */
    private static final String START_REPOSITORY_METHOD_LOG = "START repository method: %s";

    /**
     *
     */
    private static final String FINISH_REPOSITORY_METHOD_LOG = "END repository method: %s";

    /**
     *
     */
    private static final String START_METHOD_LOG = "START method: %s";

    /**
     *
     */
    private static final String FINISH_METHOD_LOG = "END method: %s";

    /**
     *
     */
    private static final String ERROR_MSG_LOG = "ERROR: %s";

    /**
     *
     */
    private static final String ERROR_LOG = "%s occurs while executing %s";

    /**
     *
     */
    private static final String EXCEPTION_LOG = "%s occurs while executing %s";

    /**
     *
     */
    private static final String WARNING_MSG_LOG = "WARNING: %s";

    /**
     *
     */
    private static final String WARNING_LOG = "%s occurs while executing %s";

    /**
     * @param requestName
     * @return
     */
    public static String requestStart(String requestName) {
        return String.format(START_REQUEST_LOG, requestName);
    }

    /**
     * @param requestName
     * @return
     */
    public static String requestEnd(String requestName) {
        return String.format(FINISH_REQUEST_LOG, requestName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String serviceStart(String serviceName) {
        return String.format(START_SERVICE_METHOD_LOG, serviceName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String serviceEnd(String serviceName) {
        return String.format(FINISH_SERVICE_METHOD_LOG, serviceName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String repositoryStart(String serviceName) {
        return String.format(START_REPOSITORY_METHOD_LOG, serviceName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String repositoryEnd(String serviceName) {
        return String.format(FINISH_REPOSITORY_METHOD_LOG, serviceName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String methodStart(String serviceName) {
        return String.format(START_METHOD_LOG, serviceName);
    }

    /**
     * @param serviceName
     * @return
     */
    public static String methodEnd(String serviceName) {
        return String.format(FINISH_METHOD_LOG, serviceName);
    }

    /**
     * @param errorMsg
     * @param e
     * @return
     */
    public static String errorLog(String errorMsg, Throwable e) {
        return String.format(ERROR_LOG, e.getClass().getSimpleName(), errorMsg);
    }

    /**
     * @param errorMsg
     * @return
     */
    public static String errorLog(String errorMsg) {
        return String.format(ERROR_MSG_LOG, errorMsg);
    }

    /**
     * @param errMsg the function where exception occurs
     * @param e      the exception
     * @return exception message
     */
    public static String warningLog(String errMsg, Throwable e) {
        return String.format(WARNING_LOG, e.getClass(), errMsg);
    }

    /**
     * @param function the function where exception occurs
     * @param e        the exception
     * @return exception message
     */
    public static String warningLog(String function) {
        return String.format(WARNING_MSG_LOG, function);
    }

    /**
     * @param function the function where exception occurs
     * @param e        the exception
     * @return exception message
     */
    public static String exceptionLog(String function, Throwable e) {
        return String.format(EXCEPTION_LOG, e.getClass(), function);
    }
}
