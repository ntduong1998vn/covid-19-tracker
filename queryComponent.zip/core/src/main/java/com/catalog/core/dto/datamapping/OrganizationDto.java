/**
 * Created by Bizhw & EPS.
 * User: Tannv
 * Created: 2019/08/20
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class OrganizationDto implements Serializable {


    /**
     * 組織コード
     **/
    @ExcelIndicator(excelPosition = 0)
    private String organizationDisplayCode;

    /**
     * 組織構造軸 - 法人軸"1"のみ
     **/
    @ExcelIndicator(excelPosition = 1)
    private String organizationStructureCd;
    /**
     * 有効開始日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 2)
    private String effectiveStartDate;
    /**
     * 有効終了日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 3)
    private String effectiveEndDate;
    /**
     * 親組織コード
     **/
    @ExcelIndicator(excelPosition = 4)
    private String parentOrganizationDisplayCode;


    @ExcelIndicator(excelPosition = 5)
    private String displayOrder;


    @ExcelIndicator(excelPosition = 6)
    private String companyGroupDisplayCode;
}
