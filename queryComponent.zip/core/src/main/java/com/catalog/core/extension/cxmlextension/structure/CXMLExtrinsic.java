package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CXMLExtrinsic {
    @JacksonXmlProperty(isAttribute=true)
    private String name;
    @JacksonXmlText
    private String value;
}
