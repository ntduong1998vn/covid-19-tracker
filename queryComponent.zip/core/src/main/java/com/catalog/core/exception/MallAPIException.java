package com.catalog.core.exception;

import org.springframework.http.HttpStatus;

public class MallAPIException  extends BaseException{
    /**
     *
     */
    private static final long serialVersionUID = -1370831544013604322L;

    public MallAPIException(String msg, String code) {
        super(msg, code);
    }

    public MallAPIException(String msg) {
        super(msg, HttpStatus.INTERNAL_SERVER_ERROR.toString());
    }
}
