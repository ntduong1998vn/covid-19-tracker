package com.catalog.core.api;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.Query;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 */
public class CoreLogger {

	/**
	 * slf4j logger
	 */
	private Logger logger;

	/**
	 * 
	 * @param clazz
	 * @return
	 */
	public static CoreLogger getLogger(final Class<?> clazz) {

		CoreLogger coreLogger = new CoreLogger();
		coreLogger.logger = LoggerFactory.getLogger(clazz);

		return coreLogger;
	}

	/**
	 * 
	 * @param requestName
	 */
	public void startRequest(String requestName) {
		logger.info(LogMessages.requestStart(requestName));
	}

	/**
	 * 
	 * @param requestName
	 * @param params
	 */
	public void startRequest(String requestName, Object... params) {
		logger.info(LogMessages.requestStart(requestName), params);
	}

	/**
	 * 
	 * @param requestName
	 */
	public void endRequest(String requestName) {
		logger.info(LogMessages.requestEnd(requestName));
	}

	/**
	 * 
	 * @param requestName
	 * @param params
	 */
	public void endRequest(String requestName, Object... params) {
		logger.info(LogMessages.requestEnd(requestName), params);
	}

	/**
	 * @param serviceFunction
	 */
	public void startService(String serviceFunction) {
		logger.info(LogMessages.serviceStart(serviceFunction));
	}

	/**
	 * 
	 * @param serviceFunction
	 * @param params
	 */
	public void startService(String serviceFunction, Object... params) {
		logger.info(LogMessages.serviceStart(serviceFunction), params);
	}

	/**
	 * 
	 * @param serviceFunction
	 */
	public void endService(String serviceFunction) {
		logger.info(LogMessages.serviceEnd(serviceFunction));
	}

	/**
	 * 
	 * @param serviceFunction
	 * @param params
	 */
	public void endService(String serviceFunction, Object... params) {
		logger.info(LogMessages.serviceEnd(serviceFunction), params);
	}

	/**
	 * 
	 * @param query
	 */
	public void logQuery(final Query query) {

	}

	/**
	 * 
	 * @param message
	 */
	public void debug(String message) {
		logger.debug(message);
	}

	/**
	 * 
	 * @param message
	 * @param params
	 */
	public void debug(String message, Object... params) {
		logger.debug(message, params);
	}

	/**
	 * 
	 * @param warnMsg
	 */
	public void warn(String warnMsg) {
		logger.warn(LogMessages.warningLog(warnMsg));
	}

	/**
	 *
	 * @param infoMsg
	 */
	public void info(String infoMsg) {
		logger.info(infoMsg);
	}

	/**
	 * 
	 * @param warnMsg
	 * @param params
	 */
	public void warn(String warnMsg, Object... params) {
		logger.warn(LogMessages.warningLog(warnMsg), params);
	}

	/**
	 * 
	 * @param functionName
	 * @param e
	 */
	public void error(String functionName, Throwable e) {
		logger.error(LogMessages.errorLog(functionName, e), e);
	}

	/**
	 * 
	 * @param functionName
	 * @param e
	 * @param params
	 */
	public void error(String functionName, Throwable e, Object... params) {

		String errMsg = formatMessage(functionName, params);
		logger.error(LogMessages.errorLog(errMsg, e), e);
	}

	/**
	 * 
	 * @param functionName
	 * @param e
	 * @param params
	 */
	public void error(String functionName, Object... params) {
		logger.error(functionName, params);
	}
	/**
	 * 
	 * @param message
	 * @param params
	 */
	public void trace(String message, Object... params) {
		logger.trace(message, params);
	}

	/**
	 * 
	 * @return
	 */
	public boolean isTraceEnabled() {
		return logger.isTraceEnabled();
	}

	/**
	 * 
	 * @return
	 */
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	/**
	 * 
	 * @param format
	 * @param values
	 * @return
	 */
	public static String formatMessage(final String format, final Object... values) {

		if (values == null || values.length == 0) {
			return format;
		}

		try {
			final List<String> tokens = new ArrayList<>();

			String[] msgArr = format.split("\\{}");

			if (msgArr == null || msgArr.length == 0) {
				return format;
			}

			int idx = -1;
			for (final String msg : msgArr) {

				tokens.add(msg);

				idx++;

				if (values.length > idx) {
					tokens.add(String.valueOf(values[idx]));
				}
			}

			return String.join("", tokens);

		} catch (Exception e) {
			return format;
		}
	}
}
