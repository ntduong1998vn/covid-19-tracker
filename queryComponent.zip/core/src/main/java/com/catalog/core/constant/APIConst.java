package com.catalog.core.constant;

import com.catalog.core.validation.ValidationResults;

public interface APIConst {

  /** */
  static final String BASE_API_URL = "/api/v1";

  /** */
  static final String MALL_API_URL = "/CatalogMall";

  static final String SEARCH_SERVICE_API_URL = "/SolrSearchService";

  static final String BATCH_PROGRAM_SERVICE_API_URL = "/BatchService";

  static final String EXECUTED_BATCH_TASK_PROGRAM_API_URL = "/ExecutedBatch";

  /** */
  static final String CATALOG_MALL_API_URL = "/MallAPI";

  /** */
  static final String SUPPLIER_API_URL = "/CMSupplier";

  /** Auth login, register */
  static final String AUTH_API_URL = "/auth";

  String MALL_MASTER_API_URL = "/CMMaster";

  /** */
  static final String SUCCESS = "success";

  /** */
  static final String ERROR = "error";

  /** */
  static final String INTERNAL = "internal";
  static final String EXCEPTION = "exception";


  /** */
  static final String ERROR_MESSAGE = "MSG000000";

  /** */
  static final String VALIDATION_ERROR = "validation_error";

  /** */
  static final ValidationResults VALIDATION_SUCCESS = new ValidationResults(APIConst.SUCCESS);

  static final String SERVICE_URL = "http://192.168.50.40:8983/solr/";

  String URL_DETAIL = "http://58.186.75.74:8087/ProductDetailRef";
}
