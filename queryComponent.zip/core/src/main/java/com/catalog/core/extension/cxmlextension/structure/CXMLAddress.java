package com.catalog.core.extension.cxmlextension.structure;

import lombok.Data;

@Data
public class CXMLAddress {
    String addressId;
    String name;
    String nameLang;
    CXMLPostal cxmlPostal = new CXMLPostal();
    String emailName;
    String emailValue;
    String phoneIsoCountryCode;
    String phoneAreaOrCityCode;
    String phoneNumber;
}
