package com.catalog.core.dto.tools;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@Data
@ToString
public class DefinedTableInsertDTO {
    String id;
    String tableName;
    List<String> listOfColumnName;
}
