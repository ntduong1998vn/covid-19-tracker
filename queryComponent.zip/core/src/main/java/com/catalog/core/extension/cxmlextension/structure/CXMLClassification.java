package com.catalog.core.extension.cxmlextension.structure;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CXMLClassification {
    private String domain;
    private String value;
}
