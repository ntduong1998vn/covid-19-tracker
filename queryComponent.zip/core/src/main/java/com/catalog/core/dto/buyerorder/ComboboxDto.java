/**
 * Created by Bizhw & EPS.
 * User: quynhpvn
 *
 * */
package com.catalog.core.dto.buyerorder;

import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@RequiredArgsConstructor
public class ComboboxDto implements Serializable {

  private String userOrganizationCode;

  private String name;

  public ComboboxDto(String userOrganizationCode, String name){

    this.userOrganizationCode = userOrganizationCode;

    this.name = name;
  }

}
