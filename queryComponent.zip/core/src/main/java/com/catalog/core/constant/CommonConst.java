package com.catalog.core.constant;

/**
 *
 */
public interface CommonConst {

    /**
     *
     */
    String JSON_UTF8 = "application/json; charset=utf-8";

    /**
     *
     */
    String CSV_FIELD_SEPARATOR = ",";

    /**
     *
     */
    String LINE_SEPARATOR = System.getProperty("line.separator");

    String NEWLINE = "\n";

    Integer SUCCESS = 2;

    Integer WARNING = 3;

    Integer ERROR = 4;

    String DOMAIN_ARIBA = "NetworkId";

    String DOMAIN_INIT = "DUNS";

    Integer NUMBER_100 = 100;

    Integer NUMBER_500 = 500;

    Integer NUMBER_1000 = 1000;

    Integer DEFAULT_MAX_UPLOAD_SIZE = 10;

    String LANG_JA_JP = "ja-JP";

    String LANG_JA = "ja";

    String DOMAIN_UNSPSC = "UNSPSC";

    String VALUE_CLASS = "44111900";

    String DATA_EXCEL = "dataExcel";

    String PERFIX = "prefix";

    String CHROME_BROWSER = "chrome";

    String IE_BROWSER = "ie";

    String SAFARI_BROWSER = "safari";

}
