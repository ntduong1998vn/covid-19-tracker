package com.catalog.core.exception.resolver;

import com.catalog.core.service.MessageResourceService;
import com.catalog.core.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;

import java.util.HashMap;
import java.util.Map;

public class ExceptionResolver {

    @Autowired
    private MessageResourceService messageResourceService;

    public Map<String, String> handleValidationExceptions(
            BindingResult result) {
        Map<String, String> errors = new HashMap<>();
        result.getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
    public Map<String, String> handleValidationErrors(
            BindingResult result) {
        Map<String, String> errors = new HashMap<>();
        result.getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = StringUtil.EMPTY;
            switch (error.getDefaultMessage()){
                case "MSG000001":
                    errorMessage = messageResourceService.getMessage("ED_REQUIRED_INPUT",null,"");
                    break;
                case "MSG000003":
                    Object[] listObjects = new Object[1];
                    listObjects[0]= (Object) error.getArguments()[1];
                    errorMessage = messageResourceService.getMessage("ED_MAXIMUM_LENGTH_EXCEEDED", listObjects,"");
                    break;
            }
            errors.put(fieldName, errorMessage);
        });
        return errors;
    }
}
