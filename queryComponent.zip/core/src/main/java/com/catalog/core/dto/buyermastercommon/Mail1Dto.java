/**
 * Created by Bizhw & EPS.
 * User: quynhpvn
 */
package com.catalog.core.dto.buyermastercommon;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Mail1Dto implements Serializable {
    private String companyCode;
    private String userDisplayCode;
    private String organizationDisplayCode;
    private String opportunityCode;
    private String systemName;
}
