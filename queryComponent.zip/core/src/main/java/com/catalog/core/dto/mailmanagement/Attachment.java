package com.catalog.core.dto.mailmanagement;

import lombok.Data;

import java.io.Serializable;

@Data
public class Attachment implements Serializable{
	private String name;
    private byte[] content;
    private String contentType;
}
