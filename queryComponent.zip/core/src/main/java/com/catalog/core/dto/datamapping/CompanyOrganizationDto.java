/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/19
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class CompanyOrganizationDto implements Serializable {

    /**
     * 会社コード
     */
    @ExcelIndicator(excelPosition = 0)
    private String companyDisplayCode;
    /**
     * 組織コード
     */
    @ExcelIndicator(excelPosition = 1)
    private String organizationDisplayCode;
    /**
     * 有効開始日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 2)
    private String effectiveStartDate;
    /**
     * 有効終了日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 3)
    private String effectiveEndDate;

 
    @ExcelIndicator(excelPosition = 4)
    private String companyGroupDisplayCode;

}
