package com.catalog.core.dto.filemanagement;

import lombok.*;

import java.util.List;
import java.util.Map;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class DataJSONToFileAnotherNameModel {
    String fileName;
    Boolean isHasHeader;
    List<Map<String, String>> dataList;
    Long numberRowHasHeader;
    String fileNameDownload;
}
