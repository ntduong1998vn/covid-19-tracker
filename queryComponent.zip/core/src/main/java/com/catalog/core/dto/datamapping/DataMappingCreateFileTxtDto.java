/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/17
 */
package com.catalog.core.dto.datamapping;

import lombok.Data;

import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;

@Data
public class DataMappingCreateFileTxtDto implements Serializable {

    List<BigInteger> itemAll;
    List<BigInteger> itemDiff;

}
