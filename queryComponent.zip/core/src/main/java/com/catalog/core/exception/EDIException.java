package com.catalog.core.exception;

public class EDIException extends RuntimeException {
  public EDIException(String message) {
    super(message);
  }
}
