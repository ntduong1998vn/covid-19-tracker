package com.catalog.core.exception;

public class LoginFailException extends BaseException {

    public LoginFailException(String msg, String code) {
        super(msg, code);
    }
}
