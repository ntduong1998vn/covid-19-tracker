package com.catalog.core.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class CSVLoadConfig {
    String encode;
    Boolean isSkipHeader;
    Boolean isIgnoreColumnChange;
    String fieldDemiliter;
    Boolean isDisableDoubleQuote;

    public CSVLoadConfig() {
        this.encode = "utf-8";
        this.isSkipHeader = true;
        this.isIgnoreColumnChange = true;
        this.fieldDemiliter = ",";
        this.isDisableDoubleQuote = false;
    }

}
