/**
 * Created by Bizhw & EPS.
 * User: quynhpvn
 */

package com.catalog.core.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UserOrgSwitchInfoDto implements Serializable {

    private static final Long serialVersionUID = 1L;

    private String userOrganizationCode;

    private boolean dutyType;

    private String organizationDisplayCode;

    private String organizationName;

    private String companyName;

}
