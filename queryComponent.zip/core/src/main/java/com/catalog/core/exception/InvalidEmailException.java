/*
 * Created by Bizhw & EPS.
 * User: thanhct
 * Copy from master common - nhuch
 */

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.catalog.core.exception;

public class InvalidEmailException extends BaseException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 8823373648576869485L;

	public InvalidEmailException() {
        super("正しいメールアドレスの形式でありません", "");
    }

}
