package com.catalog.core.exception;

public class UserNotFoundException extends BaseException {
    public UserNotFoundException(String msg, String code) {
        super(msg, code);
    }
}
