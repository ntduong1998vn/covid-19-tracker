/**
 * Created by Bizhw & EPS.
 * User: Tannv
 * Created: 2019/08/20
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class ScheduleSettingDto implements Serializable {

    /**
     * 実行API
     **/
    @ExcelIndicator(excelPosition = 0)
    private String jobName;
    /**
     * 処理区分
     **/
    @ExcelIndicator(excelPosition = 1)
    private String dataType;
    /**
     * 実行間隔
     **/
    @ExcelIndicator(excelPosition = 2)
    private String monthlyOrDaily;
    /**
     * 実行日付（Monthly指定時、第n営業日）
     **/
    @ExcelIndicator(excelPosition = 3)
    private String day;
    /**
     * 時刻
     **/
    @ExcelIndicator(excelPosition = 4)
    private String time;

    /**
     * 手動設定日
     **/
    @ExcelIndicator(excelPosition = 5)
    private String todo;

    @ExcelIndicator(excelPosition = 6)
    private String companyGroupDisplayCode;
}
