package com.catalog.core.api;

import com.catalog.core.api.dto.RestResponseDTO;
import com.catalog.core.constant.APIConst;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.time.Instant;
import java.util.Objects;

/**
 * 
 */
public final class ResponseHelper {

	/**
	 * 
	 * @param <DataModel>
	 * @param responseData
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseSuccess(final DataModel responseData) {

		return responseSuccess(responseData, null);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param responseData
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseSuccess(final DataModel responseData,
			String message) {

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.SUCCESS);
		response.setMessage(message);
		response.setData(responseData);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, HttpStatus.OK);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param header
	 * @param responseData
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseSuccess(HttpHeaders header,
			final DataModel responseData, String message) {

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.SUCCESS);
		response.setMessage(message);
		response.setData(responseData);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, header, HttpStatus.OK);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseSuccess(String message) {

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.SUCCESS);
		response.setMessage(message);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, HttpStatus.OK);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseError(String message) {

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.ERROR);
		response.setMessage(message);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, HttpStatus.OK);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseException(Throwable e) {

		return responseException(null, e);
	}

	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseException(String message,
			Throwable e) {

		String errMsg = e.getMessage();

		if (StringUtils.isBlank(errMsg)) {
			errMsg = e.getClass().getSimpleName() + " has been occurred";
		}

		String errorMessage = null;

		if (!StringUtils.isEmpty(message)) {
			errorMessage = message + ": " + errMsg;
		} else {
			errorMessage = errMsg;

		}

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.EXCEPTION);
		response.setMessage(errorMessage);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, HttpStatus.OK);
	}

	/**
	 * 
	 * @param <DataModel>
	 * @param message
	 * @return
	 */
	public static <DataModel> ResponseEntity<RestResponseDTO<DataModel>> responseValidationError(String message) {

		RestResponseDTO<DataModel> response = createRestResponse();

		response.setStatus(APIConst.VALIDATION_ERROR);
		response.setMessage(message);

		return new ResponseEntity<RestResponseDTO<DataModel>>(response, HttpStatus.OK);
	}

	/**
	 * Create new instance of RestResponseDTO with some common properties.
	 * 
	 * @param <DataModel>
	 * @return
	 */
	public static <DataModel> RestResponseDTO<DataModel> createRestResponse() {

		RestResponseDTO<DataModel> response = new RestResponseDTO<>();

		// Set current time
		response.setTimestamp(Instant.now());

		if (Objects.nonNull(RequestContextHolder.getRequestAttributes())) {

			HttpServletRequest httpServletRequest = ((ServletRequestAttributes) RequestContextHolder
					.getRequestAttributes()).getRequest();

			response.setRequestPath(httpServletRequest.getServletPath());
		}

		return response;
	}
}
