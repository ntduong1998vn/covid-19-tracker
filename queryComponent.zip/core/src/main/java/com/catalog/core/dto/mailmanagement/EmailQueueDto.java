package com.catalog.core.dto.mailmanagement;

import lombok.Data;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import java.util.Map;

@Data
public class EmailQueueDto implements Serializable {
    private String mailFrom;
    private String language;
    private String companyGroupCode;    //New require: this is companyGroupDisplayCode
    private String templateCode;
    private Collection<String> mailTo;
    private Collection<String> mailCc;
    private Collection<String> mailBcc;
    private Map<String, Object> paramTemplates;
    private Map<String, Object> paramSubjectTemplates;
    private List<Attachment> attachments;
    private Integer timeZoneOffset;    //Please get timezone of user
}
