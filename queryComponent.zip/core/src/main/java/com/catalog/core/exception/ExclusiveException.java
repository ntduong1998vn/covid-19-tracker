package com.catalog.core.exception;

/**
 * 対象レコードは既に更新されました。
 *
 * 
 */
public class ExclusiveException extends BaseException {
	
    /**
	 * 
	 */
	private static final long serialVersionUID = -2931679148382600688L;

	public ExclusiveException() {
        super("対象レコードは既に更新されました。", "MSG_0008");
    }
    
    public ExclusiveException(String message) {
        super(message, "");
    }
}
