/*
 * Created by Bizhw & EPS.
 * User: ThaiHV
 *
 */

package com.catalog.core.constant;


/**
 * ==> NOTE: FeignProxyMasterUrlConst stores MASTER Service URL [OAUTH / MASTER-COMMON / BUYER-MASTER-COMMON]
 */
public class FeignProxyMasterUrlConst {

    /** ==== Authentication API ==== --[START]-- **/

    public final static String GET_USER_COMMON_INFO = "/user/common-info";

    public final static String GET_USER_AUTHEN = "/user/authen";

    public final static String GET_USER_LOGIN_INFO = "/user/info";

    public final static String GET_CATALOG_MALL_AUTHEN = "/catalogmall/authen";

    public final static String GET_SERVICE_AUTHEN = "/service-app/authen";

    public final static String LOGIN_MAPPING = "/jwt/signin";

    public static final String SIGN_OUT_MAPPING = "/jwt/signout";

    public final static String PASSWORD_CHANGE_MAPPING = "/jwt/password/change";

    public final static String FORGOT_PASSWORD_MAPPING = "/jwt/password/forgot";

    public final static String RESET_PASSWORD_MAPPING = "/jwt/reset";

    public final static String EMAIL = "email";

    public final static String PASSWORD = "password";

    public final static String KEY_SESSION_TEMP = "ks-temp";

    public static final String STORE_SCREEN_AND_API_PATH  = "/store-screen-and-api-path";

    public static final String CHECK_ROLE_API  = "/check-role-api";

    public final static String REQUEST_RESET_USER_PASSWORD = "/account/request-reset-password";

    public final static String RESET_USER_PASSWORD = "/account/reset-password";

    public final static String CHANGE_USER_PASSWORD = "/user/change-password";

    /** ==== Authentication API ==== --[END]-- **/


    /** ==== Import/Export API (MASTER-DATA) ==== --[START]-- **/
    public static final String GET_ACCOUNT_TITLE_MASTER_LIST = "/master/account-title/list";
    public static final String IMPORT_ACCOUNT_TITLE_MASTER = "/master/account-title/import";

    public static final String GET_BUSINESS_PLACE_MASTER_LIST = "/master/business-place/list";
    public static final String IMPORT_BUSINESS_PLACE_MASTER = "/master/business-place/import";

    public static final String GET_COST_CENTER_MASTER_LIST = "/master/cost-center/list";
    public static final String IMPORT_COST_CENTER_MASTER = "/master/cost-center/import";

    public static final String GET_CATALOG_MALL_SYSTEM_LINK_LIST = "/master/catalog-mall-system-link/list";
    public static final String IMPORT_CATALOG_MALL_SYSTEM_LINK_MASTER = "/master/catalog-mall-system-link/import";

    public static final String GET_INTERNAL_ORDER_MASTER_LIST = "/master/internal-order/list";
    public static final String IMPORT_INTERNAL_ORDER_MASTER = "/master/internal-order/import";

    public static final String GET_ACCOUNT_TITLE_TYPE_RELATION_MASTER_LIST = "/master/account-title-type-relation/list";
    public static final String IMPORT_ACCOUNT_TITLE_TYPE_RELATION_MASTER = "/master/account-title-type-relation/import";

    public static final String GET_ACCEPTANCE_SUSPEND_PERIOD_MASTER_LIST = "/master/acceptance-suspend-period/list";
    public static final String IMPORT_ACCEPTANCE_SUSPEND_PERIOD_MASTER = "/master/acceptance-suspend-period/import";

    public static final String IMPORT_SCREEN_MASTER = "/master/screen/import";
    public static final String GET_COMPANY_DATASOURCE = "/master/get-company-datasource";

    public static final String GET_COMPANY_GROUP_MASTER_LIST = "/master/company-group/list";
    public static final String IMPORT_COMPANY_GROUP_MASTER = "/supplier/company-group/import";

    /** ==== Import/Export API (MASTER-DATA) ==== --[END]-- **/


    /** ==== Pull Down API URL (MASTER-COMMON Service) ==== --[START]-- **/

    public static final String GET_COMPANY_GROUP_PULL_DOWN_BY_MASTER_TYPE = "/pull-down/company-group-by-master-type";
    public static final String GET_COMPANY_GROUP_CODE_FROM_DISPLAY_CODE = "/mail/company-group-code-from-display-code";

    /** ==== Pull Down API URL (MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Static Entity API URL (MASTER-COMMON Service) ==== --[START]-- **/
    public static final String FIND_STATIC_ENTITY_BY_TYPECODE = "/static-by-type-code";

    /** ==== Static Entity API URL (MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Pull Down API URL (BUYER-MASTER-COMMON Service) ==== --[START]-- **/
    public static final String GET_DATASOURCE_NAME_LIST = "/get-datasource-name-list";

    /** ==== Pull Down API URL (BUYER-MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Shared API URL (MASTER-COMMON Service) ==== --[START]-- **/

    public static final String GET_BUYER_DATA_SOURCE_BY_CODE = "/get-buyer-data-source-by-code";
    public static final String GET_PASSWORD_RULE_BY_CODE = "/password-rule-by-code";

    /** ==== Shared API URL (MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Shared API URL (BUYER-MASTER-COMMON Service) ==== --[START]-- **/

    public static final String REGISTER_UPDATE_BUYER_COMPANY_GROUP_MASTER = "/buyer/master/company-group/save";
    public static final String DELETE_BUYER_COMPANY_GROUP_MASTER = "/buyer/master/company-group/delete";

    /** ==== Shared API URL (BUYER-MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Shared API URL (SUPPLIER Service) ==== --[START]-- **/

    public static final String DELETE_COMPANY_GROUP_MASTER = "/supplier/master/company-group/delete";
    public static final String IMPORT_DELETE_COMPANY_GROUP_MASTER = "/supplier/master/company-group/delete-import";
    public static final String REGISTER_UPDATE_SUPPLIER_COMPANY_GROUP_MASTER = "/supplier/master/company-group/save";

    /** ==== Shared API URL (SUPPLIER Service) ==== --[END]-- **/

    /** ==== Master import history ==== --[START]-- **/
    public static final String SEARCH_MASTER_IMPORT_HISTORY_BUYER = "/buyer/master/import-history/list";
    
    public static final String SEARCH_MASTER_IMPORT_HISTORY_SUPPLIER = "/supplier/master/import-history/list";

    public static final String DELETE_MASTER_IMPORT_HISTORY_BUYER = "/buyer/master/import-history/delete";

    public static final String DELETE_MASTER_IMPORT_HISTORY_SUPPLIER = "/supplier/master/import-history/delete";

    /** ==== Shared API URL (Upload Management) ==== --[START]-- **/

    public static final String INSERT_UPLOAD_MANAGEMENT = "/insert-upload-management";

    public static final String UPDATE_UPLOAD_MANAGEMENT = "/update-upload-management";

    public static final String INSERT_META_DATA = "/insert-meta-data";

    /** ==== Shared API URL (Upload Management) ==== --[END]-- **/

}
