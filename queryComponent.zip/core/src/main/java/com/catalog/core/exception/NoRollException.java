package com.catalog.core.exception;

public class NoRollException extends BaseException{
    /**
     *
     */
    private static final long serialVersionUID = -1370831544013604322L;

    public NoRollException(String msg, String code) {
        super(msg, code);
    }
}
