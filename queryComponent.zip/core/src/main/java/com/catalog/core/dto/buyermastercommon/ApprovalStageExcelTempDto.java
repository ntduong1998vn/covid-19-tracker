package com.catalog.core.dto.buyermastercommon;

import com.catalog.core.util.StringUtil;
import lombok.Data;

/**
 * Approval Stage Exel Temp Dto
 *
 * @author Create by DuyPHA on 2019/07/29 at 10:41 AM
 */
@Data
//@NoArgsConstructor
public class ApprovalStageExcelTempDto {

    /**
     *
     */
    private String approvalStageCode;

    /**
     *
     */
    private String ruleCode;

    /**
     *
     */
    private String stageNo;

    /**
     * 段階
     * 承認組織
     */
    private String orgType;

    /**
     * 段階
     * 組織コード
     */
    private String orgCode;

    /**
     * 段階
     * 上位含む
     */
    private String orgUpper;

    /**
     * 段階
     * 承認者
     */
    private String levelType;

    /**
     * 段階
     * 承認レベル
     */
    private String level;

    public ApprovalStageExcelTempDto(String approvalStageCode, String ruleCode, Integer stageNo, String orgType,
                                     String orgCode, Boolean isOrgUpper, String levelType, Integer level){

        this.approvalStageCode = approvalStageCode;

        this.ruleCode = ruleCode;

        this.stageNo = StringUtil.toString(stageNo);

        this.orgType = orgType;

        this.orgCode = orgCode;

        if(isOrgUpper != null){
            this.orgUpper =  isOrgUpper ? "YES" : "NO";
        }

        this.levelType = levelType;

        this.level = StringUtil.toString(level);
    }
}
