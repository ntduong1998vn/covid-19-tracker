/**
 * Created by Bizhw & EPS.
 * User: khanhlt
 */
package com.catalog.core.dto.authentication;

import lombok.*;

import java.io.Serializable;


@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserPasswordRule implements Serializable {

    private String displayCode;

    private String name;

    private Integer effectiveTerm;

    private Boolean needAlphabeticChar;

    private Boolean needNumericChar;

    private Boolean needSymbolicChar;

    private Integer minLength;

}
