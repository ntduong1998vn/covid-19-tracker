package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.filemanagement.MetaDataFileDto;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class DataMappingTransferDto implements Serializable {

    private String codeManagement;

    private Boolean isDataMapping;

    private List<MetaDataFileDto> metaData;

}
