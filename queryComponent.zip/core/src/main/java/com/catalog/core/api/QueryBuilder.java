package com.catalog.core.api;

import org.springframework.data.domain.Pageable;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class QueryBuilder {

	/**
	 * 
	 */
	private static final CoreLogger logger = CoreLogger.getLogger(QueryBuilder.class);

	private final StringBuilder selectBuilder;
	private final StringBuilder fromBuilder;
	private final StringBuilder whereBuilder;
	private final StringBuilder orderByBuilder;
	private final StringBuilder groupByBuilder;

	private final Map<String, Object> queryParams;

	private int firstResult;
	private int maxResults;

	public QueryBuilder() {
		this(new StringBuilder(), new StringBuilder(), new StringBuilder(), new StringBuilder(), new StringBuilder(),
				new HashMap<>());
	}

	public QueryBuilder(final StringBuilder selectBuilder, final StringBuilder fromBuilder,
			final StringBuilder whereBuilder, final StringBuilder orderByBuilder, final StringBuilder groupByBuilder,
			final Map<String, Object> queryParams) {

		if (selectBuilder == null || fromBuilder == null || whereBuilder == null || orderByBuilder == null
				|| groupByBuilder == null || queryParams == null) {
			throw new IllegalArgumentException("Params should not be null.");
		}

		this.selectBuilder = selectBuilder;
		this.fromBuilder = fromBuilder;
		this.whereBuilder = whereBuilder;
		this.orderByBuilder = orderByBuilder;
		this.groupByBuilder = groupByBuilder;
		this.queryParams = queryParams;

		this.firstResult = -1;
		this.maxResults = -1;
	}

	public int getFirstResult() {
		return firstResult;
	}

	public void setFirstResult(int firstResult) {
		this.firstResult = firstResult;
	}

	public int getMaxResults() {
		return maxResults;
	}

	public void setMaxResults(int maxResults) {
		this.maxResults = maxResults;
	}

	public Map<String, Object> getQueryParams() {
		return queryParams;
	}

	public QueryBuilder select(String select) {

		if (selectBuilder.length() > 0) {
			selectBuilder.append(", ");
		}

		selectBuilder.append(select);

		return this;
	}

	public QueryBuilder select(String... selectList) {

		for (String select : selectList) {
			this.select(select);
		}

		return this;
	}

	public QueryBuilder from(Class<?> from) {
		return from(from.getName());
	}

	public QueryBuilder from(Class<?> from, String alias) {
		return from(from.getName(), alias);
	}

	public QueryBuilder from(String from) {

		return from(from, null);
	}

	public QueryBuilder from(String from, String alias) {

		if (from == null || from.isEmpty()) {
			return this;
		}

		fromBuilder.append("\n");

		fromBuilder.append(" from ").append(from);

		if (alias != null && !alias.trim().isEmpty()) {
			fromBuilder.append(" as ").append(alias);
		}

		return this;
	}

	public QueryBuilder join(String join) {

		return join(join, null);
	}

	public QueryBuilder join(String join, String alias) {

		if (join == null || join.isEmpty()) {
			return this;
		}

		fromBuilder.append("\n");

		fromBuilder.append(" join ").append(join);

		if (alias != null && !alias.trim().isEmpty()) {
			fromBuilder.append(" as ").append(alias);
		}

		return this;
	}

	public QueryBuilder leftJoin(String join) {
		return leftJoin(join, null);
	}

	public QueryBuilder leftJoin(String join, String alias) {

		if (join == null || join.isEmpty()) {
			return this;
		}

		fromBuilder.append("\n");

		fromBuilder.append(" left outer join ").append(join);

		if (alias != null && !alias.trim().isEmpty()) {
			fromBuilder.append(" as ").append(alias);
		}

		return this;
	}

	public QueryBuilder orderBy(List<String> orderBys) {

		if (orderBys == null || orderBys.isEmpty()) {
			return this;
		}

		for (String orderBy : orderBys) {

			if (orderBy == null || orderBy.isEmpty()) {
				continue;
			}

			if (orderByBuilder.length() > 0) {
				orderByBuilder.append(", ");
			}

			this.orderByBuilder.append(orderBy);
		}

		return this;
	}

	public QueryBuilder orderBy(String... orderBys) {

		if (orderBys == null || orderBys.length == 0) {
			return this;
		}

		return orderBy(Arrays.asList(orderBys));
	}

	public QueryBuilder groupBy(List<String> groupBys) {

		if (groupBys == null || groupBys.isEmpty()) {
			return this;
		}

		for (String orderBy : groupBys) {

			if (orderBy == null || orderBy.isEmpty()) {
				continue;
			}

			if (groupByBuilder.length() > 0) {
				groupByBuilder.append(", ");
			}

			this.groupByBuilder.append(orderBy);
		}

		return this;
	}

	public QueryBuilder groupBy(String... groupBys) {

		if (groupBys == null || groupBys.length == 0) {
			return this;
		}

		return groupBy(Arrays.asList(groupBys));
	}

	public QueryBuilder and(String... conditions) {

		if (conditions == null || conditions.length == 0) {
			return this;
		}

		for (String condition : conditions) {

			if (condition == null || condition.isEmpty()) {
				continue;
			}

			if (whereBuilder.length() > 0) {
				whereBuilder.append(" and ");
			}

			whereBuilder.append(condition);
		}

		return this;
	}

	public QueryBuilder params(String key, Object value) {

		queryParams.put(key, value);

		return this;
	}

	public QueryBuilder pagination(final Pageable pagination) {

		if (pagination == null) {
			firstResult = -1;
			maxResults = -1;

			return this;
		}

		// zero - based index;
		int pageNum = pagination.getPageNumber();
		int pageSize = pagination.getPageSize();

		firstResult = pageNum * pageSize;
		maxResults = pageSize;

		if (firstResult < 0) {
			firstResult = 0;
		}

		if (maxResults < 0) {
			maxResults = 0;
		}

		return this;
	}

	public String toHqlQuery() throws RuntimeException {

		if (fromBuilder == null) {
			logger.warn("Could not build hql query. Error: fromBuilder is NULL.");
			return null;
		}

		String hql = "";

		try {

			if (selectBuilder != null) {
				String selectStatement = selectBuilder.toString().trim();

				if (!selectStatement.toLowerCase().startsWith("select")) {
					selectStatement = "select ".concat(selectStatement);
				}

				hql = hql.concat(selectStatement).concat(" ");
			}

			hql = hql.concat("\n");

			hql = hql.concat(fromBuilder.toString());

			hql = hql.concat("\n");

			if (whereBuilder != null && whereBuilder.length() > 0) {
				hql = hql.concat(" where ").concat(whereBuilder.toString());
			}

			hql = hql.concat("\n");

			if (groupByBuilder != null && groupByBuilder.length() > 0) {
				hql = hql.concat(" group by ").concat(groupByBuilder.toString());
			}

			hql = hql.concat("\n");

			if (orderByBuilder != null && orderByBuilder.length() > 0) {
				hql = hql.concat(" order by ").concat(orderByBuilder.toString());
			}

		} catch (RuntimeException e) {
			logger.error("build hql query", e);
			throw e;
		}

		return hql;
	}

	public static String orStatement(final List<String> conditions) {

		if (conditions == null || conditions.isEmpty()) {
			return null;
		}

		return orStatement(conditions.toArray(new String[0]));
	}

	public static String orStatement(final String... conditions) {

		if (conditions == null || conditions.length == 0) {
			return null;
		}

		return "(".concat(String.join(" or ", conditions)).concat(")");

	}

	public static String iEqual(String left, String right) {

		String pattern = "lower(%s) = lower(%s)";

		return String.format(pattern, left, right);
	}

	public static String iLike(String left, String right) {

		String pattern = "lower(%s) like lower(%s)";

		return String.format(pattern, left, right);
	}

	public static String toLike(String val) {
		return toLike(val, false);
	}

	public static String toLike(String val, boolean escapingSpecialCharacter) {

		if (val == null) {
			return "%";
		}

		String param = "%".concat(val).concat("%");

		if (escapingSpecialCharacter) {
			param = escape(param).concat(" escape '!' ");
		}

		return param;
	}

	public static String escape(String value) {
		return value.replace("!", "!!").replace("%", "!%").replace("_", "!_");
	}

}
