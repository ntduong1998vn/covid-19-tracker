package com.catalog.core.dto.tools;

import lombok.Data;
import lombok.ToString;

@Data
@ToString
public class ItemExpectedOutputDTO {
    String id;
    Boolean status;
    String message;
}
