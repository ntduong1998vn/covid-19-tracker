package com.catalog.core.api.util;

import com.catalog.core.api.dto.AppInfoDTO;
import com.catalog.core.constant.APIConst;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.env.Environment;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * 
 * @author HANV
 *
 */
public class WebUtil {

	/**
	 * By default, Spring Boot uses the 8080 port number to start the Tomcat.
	 */
	public static final String SPRING_DEFAULT_PORT = "8080";

	/**
	 * 
	 * @param env
	 * @return
	 */
	public static AppInfoDTO getApplicationInfo(Environment env) {

		String protocol = "http";
		if (env.getProperty("server.ssl.key-store") != null) {
			protocol = "https";
		}

		String serverPort = env.getProperty("server.port");
		String contextPath = env.getProperty("server.servlet.context-path");

		if (StringUtils.isNotBlank(contextPath) && contextPath.endsWith("/")) {
			contextPath = contextPath.substring(0, contextPath.length() - 1);
		}

		if (StringUtils.isBlank(contextPath)) {
			contextPath = "";
		}

		if (StringUtils.isBlank(serverPort)) {
			serverPort = SPRING_DEFAULT_PORT;
		}

		String hostAddress = "localhost";
		try {
			hostAddress = InetAddress.getLocalHost().getHostAddress();

		} catch (UnknownHostException e) {
			System.out.println("The host name could not be determined, using `localhost` as fallback");
		}

		String localBaseUrl = String.format("%s://%s:%s%s", protocol, "localhost", serverPort, contextPath);
		String baseUrl = String.format("%s://%s:%s%s", protocol, hostAddress, serverPort, contextPath);

		localBaseUrl = localBaseUrl + APIConst.BASE_API_URL;
		baseUrl = baseUrl + APIConst.BASE_API_URL;
		
		String generateDdl = env.getProperty("spring.jpa.generate-ddl");
		String ddlAuto = env.getProperty("spring.jpa.hibernate.ddl-auto");

		AppInfoDTO infoModel = new AppInfoDTO();

		infoModel.setApplicationName(env.getProperty("spring.application.name"));
		infoModel.setLocalBaseUrl(localBaseUrl);
		infoModel.setBaseUrl(baseUrl);
		infoModel.setActiveProfiles(env.getActiveProfiles());

		return infoModel;
	}
}
