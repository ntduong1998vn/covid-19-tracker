package com.catalog.core.exception;

public class InvalidImportMasterDataInputException extends BaseException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -320190722760791695L;

	public InvalidImportMasterDataInputException(String message) {
		super(message, "");
	}
}
