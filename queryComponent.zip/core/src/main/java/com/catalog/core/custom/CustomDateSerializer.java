/**
 * Created by Bizhw & EPS.
 * User: ThaiHV
 */

package com.catalog.core.custom;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

/*
 * @Note:
 * Server response Date [2019-01-25T05:05:05.000+0700]
 * ==Serializer=>
 * Client gets json {"date": "2019-01-25 05:05:05"} Date
 * */

@Component
public class CustomDateSerializer extends StdSerializer<Date> implements ContextualSerializer {

    private static final long serialVersionUID = 1L;
    private SimpleDateFormat formatter = new SimpleDateFormat();
    private JsonFormat jsonFormatAnnotation;

    public CustomDateSerializer() {
        this(null);
    }

    public CustomDateSerializer(Class vc) {
        super(vc);
    }

    @Override
    public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
        // get field's pattern bases on @JsonFormat annotation
        this.jsonFormatAnnotation = property.getAnnotation(JsonFormat.class);
        return this;
    }

    @Override
    public void serialize(Date value, JsonGenerator gen, SerializerProvider provider) throws IOException {
        if (Objects.isNull(jsonFormatAnnotation)) {
            throw new NullPointerException("Date format pattern doesn't exist [@JsonFormat]");
        }
        formatter.applyPattern(jsonFormatAnnotation.pattern());
        gen.writeString(formatter.format(value));
    }
}