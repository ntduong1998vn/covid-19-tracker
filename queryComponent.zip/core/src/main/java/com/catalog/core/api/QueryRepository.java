package com.catalog.core.api;

import com.catalog.core.util.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.internal.QueryImpl;
import org.hibernate.transform.AliasToEntityMapResultTransformer;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;
import java.util.Map;

//import org.hibernate.query.Query;

/**
 * 
 */
@Repository
@Transactional
public class QueryRepository {

	/**
	 * 
	 */
	private static final CoreLogger logger = CoreLogger.getLogger(QueryRepository.class);

	/**
	 * 
	 */
	@PersistenceContext
	private EntityManager entityManager;

	/**
	 * 
	 * @param queryBuilder
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public int selectCount(final QueryBuilder queryBuilder) {

		List<Long> rsList = getList(queryBuilder);

		if (rsList == null || rsList.isEmpty()) {
			return 0;
		}

		Long rs = rsList.get(0);

		return rs.intValue();
	}

	/**
	 * 
	 * @param <Model>
	 * @param queryBuilder
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public <Model> Model getOne(final QueryBuilder queryBuilder) {

		List<Model> rsList = getList(queryBuilder);

		if (rsList == null || rsList.isEmpty()) {
			return null;
		}

		Model rs = rsList.get(0);

		return rs;
	}

	/**
	 * 
	 * @param queryBuilder
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public Map<String, Object> getMap(final QueryBuilder queryBuilder) {

		List<Map<String, Object>> mapList = getMapList(queryBuilder);

		if (mapList == null || mapList.isEmpty()) {
			return null;
		}

		return mapList.get(0);
	}

	/**
	 * 
	 * @param queryBuilder
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public List<Map<String, Object>> getMapList(final QueryBuilder queryBuilder) {

		Query query = createQuery(queryBuilder);

		if (query != null) {
			// Map query result to list of Java HashMap
			((QueryImpl<?>) query).setResultTransformer(AliasToEntityMapResultTransformer.INSTANCE);
		}

		return queryList(queryBuilder, query);
	}

	/**
	 * 
	 * @param <Model>
	 * @param queryBuilder
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public <Model> List<Model> getList(final QueryBuilder queryBuilder) {

		return getList(queryBuilder, null);

	}

	/**
	 * 
	 * @param <Model>
	 * @param queryBuilder
	 * @param pageable
	 * @return
	 */
	@Transactional(readOnly = true, propagation = Propagation.SUPPORTS)
	public <Model> List<Model> getList(final QueryBuilder queryBuilder, final Pageable pageable) {

		if (pageable != null) {
			queryBuilder.setMaxResults(pageable.getPageSize());
			queryBuilder.setFirstResult(pageable.getPageNumber() - 1);
		}

		Query query = createQuery(queryBuilder);

		return queryList(queryBuilder, query);

	}

	/**
	 * 
	 * @param <Model>
	 * @param queryString
	 * @param parameters
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public <Model> List<Model> getList(final String queryString, final Map<String, Object> parameters) {

		Query query = createQuery(queryString, parameters);

		List<Model> list = null;

		try {
			// Execute query
			list = query.getResultList();

		}
		catch (RuntimeException e) {

			logger.error("Execute query", e);

			throw e;
		}

		return list;
	}

	/**
	 * 
	 * @param queryString
	 * @param parameters
	 * @return
	 */
	public Query createQuery(final String queryString, final Map<String, Object> parameters) {

		Query query = null;

		try {
			// Create Hibernate Query
			query = entityManager.createQuery(queryString);

		}
		catch (RuntimeException e) {
			logger.error("Create hql: " + queryString, e);

			throw e;
		}

		if (parameters != null && !parameters.isEmpty()) {

			for (Map.Entry<String, Object> param : parameters.entrySet()) {

				if (param != null) {

					try {
						query.setParameter(param.getKey(), param.getValue());

					}
					catch (RuntimeException e) {
						String errMsg = "add query param [param-name: {}, param-value: {}] ";
						logger.error(errMsg, e, param.getKey(), param.getValue());

						throw e;
					}
				}
			}
		}

		return query;
	}

	/**
	 * 
	 * @param queryBuilder
	 * @return
	 */
	protected Query createQuery(final QueryBuilder queryBuilder) {

		if (queryBuilder == null) {
			logger.warn("Could not execute hql query. Error: queryBuilder is NULL.");
			return null;
		}

		// Build hql query
		String hqlQuery = queryBuilder.toHqlQuery();

		if (hqlQuery == null) {
			return null;
		}

		try {
			// Create Hibernate Query
			Query query = entityManager.createQuery(hqlQuery);

			return query;

		}
		catch (RuntimeException e) {
			logger.error("Create hql: " + hqlQuery, e);

			throw e;
		}

	}

	/**
	 * 
	 * @param <Model>
	 * @param queryBuilder
	 * @param query
	 * @return
	 */
	@SuppressWarnings("unchecked")
	protected <Model> List<Model> queryList(final QueryBuilder queryBuilder, final Query query) {

		if (query == null) {
			return null;
		}

		// Add query params
		addQueryParams(queryBuilder, query);

		List<Model> list = null;

		try {
			// Execute query
			list = query.getResultList();

		}
		catch (RuntimeException e) {

			logger.error("Execute query", e);

			throw e;
		}

		// Write log info if the query returns NO record.
		logIfNoRowReturns(queryBuilder, list);

		return list;
	}

	/**
	 * 
	 * @param queryBuilder
	 * @param query
	 */
	private void addQueryParams(final QueryBuilder queryBuilder, final Query query) {

		if (queryBuilder == null || query == null) {
			return;
		}

		try {

			// Add query parameters
			final Map<String, Object> whereParams = queryBuilder.getQueryParams();

			if (whereParams != null && !whereParams.isEmpty()) {

				whereParams.entrySet().forEach(whereParam -> {

					if (whereParam != null) {
						query.setParameter(whereParam.getKey(), whereParam.getValue());
					}
				});
			}

			// Pagination
			int firstResult = queryBuilder.getFirstResult();
			int maxResults = queryBuilder.getMaxResults();

			if (firstResult >= 0) {
				query.setFirstResult(firstResult);
			}

			if (maxResults > 0) {
				query.setMaxResults(maxResults);
			}

		}
		catch (RuntimeException e) {
			logger.error("Setting params for query", e);
			throw e;
		}
	}

	/**
	 * 
	 * @param queryBuilder
	 * @param list
	 */
	private void logIfNoRowReturns(final QueryBuilder queryBuilder, final List<?> list) {

		if (!logger.isTraceEnabled()) {
			return;
		}

		if (ListUtils.isNotEmpty(list) || queryBuilder == null) {
			return;
		}

		try {
			String logMsg = "The following query returns NO record:\n{}\nQuery params: {}\n";
			logger.trace(logMsg, queryBuilder.toHqlQuery(), StringUtils.join(queryBuilder.getQueryParams()));

		}
		catch (RuntimeException e) {
			// Just a log issue. Do nothing.
		}
	}

}
