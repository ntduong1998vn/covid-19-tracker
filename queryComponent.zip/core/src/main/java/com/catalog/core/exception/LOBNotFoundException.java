package com.catalog.core.exception;

public class LOBNotFoundException extends BaseException {
    public LOBNotFoundException(String msg, String code) {
        super(msg, code);
    }
}
