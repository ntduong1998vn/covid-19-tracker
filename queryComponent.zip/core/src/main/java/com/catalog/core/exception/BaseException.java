package com.catalog.core.exception;

import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@NoArgsConstructor
public class BaseException extends RuntimeException {

    /**
     *
     */
    private static final long serialVersionUID = -8611661445958252333L;

    private String code;
    /**
     *
     */
    private String message;

    public BaseException(String msg, String code) {
        this.message = msg;
        this.code = code;
    }

    /**
     * @param message
     */
    public BaseException(String message) {
        this.message = message;
    }

    /**
     *
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
