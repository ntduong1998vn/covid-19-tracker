package com.catalog.core.dto.tools;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class DemoCheckValidDTO {
    String id;
    String name;
    Date date;
    String email;
    Long phoneNumber;
    String validMessage;

    @Override
    public String toString() {
        return "\nDemoCheckValidDTO{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", date=" + date +
                ", email='" + email + '\'' +
                ", phoneNumber=" + phoneNumber +
                ", validMessage='" + validMessage + '\'' +
                '}';
    }
}
