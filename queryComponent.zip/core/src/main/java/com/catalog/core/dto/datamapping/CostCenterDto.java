/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/16
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class CostCenterDto implements Serializable {

    /**
     * 原価センタ
     */
    @ExcelIndicator(excelPosition = 0)
    private String costCenterDisplayCode;
    /**
     * 有効開始日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 1)
    private String effectiveStartDate;
    /**
     * 有効終了日,YYYYMMDD
     */
    @ExcelIndicator(excelPosition = 2)
    private String effectiveEndDate;
    /**
     * 名称
     */
    @ExcelIndicator(excelPosition = 3)
    private String name;
    /**
     * テキスト
     */
    @ExcelIndicator(excelPosition = 4)
    private String text;
    /**
     * 会社コード
     */
    @ExcelIndicator(excelPosition = 5)
    private String companyDisplayCode;
    /**
     * 事業領域
     */
    @ExcelIndicator(excelPosition = 6)
    private String businessDomain;
    /**
     * 利益センタ
     */
    @ExcelIndicator(excelPosition = 7)
    private String accountCenterCd;
    /**
     * 実績一次転記用ロックフラグ
     */
    @ExcelIndicator(excelPosition = 8)
    private String tempLockFlagForPosting;
    /**
     * 計画一次原価ロックフラグ
     */
    @ExcelIndicator(excelPosition = 9)
    private String costLockFlagForPlan;
    /**
     * 目的区分
     */
    @ExcelIndicator(excelPosition = 10)
    private String purposeTypeCd;
    /**
     * 企業グループコード
     */
    @ExcelIndicator(excelPosition = 11)
    private String companyIdentifierCd;

    @ExcelIndicator(excelPosition = 12)
    private String companyGroupDisplayCode;
}
