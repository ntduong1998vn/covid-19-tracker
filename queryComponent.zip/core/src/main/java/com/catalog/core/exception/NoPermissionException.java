package com.catalog.core.exception;

public class NoPermissionException extends BaseException {

	/**
	 *
	 */
	private static final long serialVersionUID = -1370831544013604322L;

	public NoPermissionException(String msg, String code) {
		super(msg, code);
	}
}
