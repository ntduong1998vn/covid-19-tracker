package com.catalog.core.dto.buyermastercommon;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Org Rule Setting Excel Dto
 *
 * @author Create by DuyPHA on 2019/07/22 at 09:55 AM
 */
@Data
@NoArgsConstructor
public class OrgRuleSettingInfoExcelDto {

    /**
     * 企業グループコード
     */
    private String companyGroupCode;

    /**
     * 会社コード
     */
    private String companyCode;

    /**
     * 組織コード
     */
    private String organizationCode;

    /**
     * 買い方
     */
    private String orderClassificationName;

    /**
     * 発注
     */
    private String wfSettingOrder;

    /**
     * 検収
     */
    private String wfSettingAcceptance;

    /**
     * 見積依頼
     */
    private String wfSettingEstimatesRequest;

    /**
     * 見積選定
     */
    private String wfSettingEstimatesSelect;

    /**
     * 仮発注
     */
    private String wfSettingProvisionalOrder;
}
