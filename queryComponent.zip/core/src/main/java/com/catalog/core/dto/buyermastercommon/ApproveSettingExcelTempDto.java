package com.catalog.core.dto.buyermastercommon;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Approve Setting Excel Temp Dto
 *
 * @author Create by DuyPHA on 2019/07/26 at 10:10 AM
 */
@Data
@NoArgsConstructor
public class ApproveSettingExcelTempDto {

    /**
     * 企業グループコード
     */
    private String companyGroupCode;

    /**
     * 承認設定コード
     */
    private String approveSettingCode;

    /**
     * 承認設定名
     */
    private String approveSettingDescription;

    /**
     * ルールセットコード
     */
    private String ruleSetCode;

    /**
     * ルールセット名
     */
    private String ruleSetName;

    /**
     * ルールコード
     */
    private String ruleCode;

    /**
     * ルール名
     */
    private String ruleName;

    /**
     * AND/OR
     */
    private Boolean ruleConditionOR;

    /**
     * 次のルールセット
     */
    private String nextRuleSetCode;

    public ApproveSettingExcelTempDto(String companyGroupCode, String approveSettingCode, String approveSettingDescription,
                                      String ruleSetCode, String ruleSetName, String ruleCode, String ruleName,
                                      Boolean ruleConditionOR, String nextRuleSetCode){

        this.companyGroupCode = companyGroupCode;

        this.approveSettingCode = approveSettingCode;

        this.approveSettingDescription = approveSettingDescription;

        this.ruleSetCode = ruleSetCode;

        this.ruleSetName = ruleSetName;

        this.ruleCode = ruleCode;

        this.ruleName = ruleName;

        this.ruleConditionOR = ruleConditionOR;

        this.nextRuleSetCode = nextRuleSetCode;
    }
}
