/**
 *
 */
package com.catalog.core.dto;

import java.lang.annotation.*;

@Documented
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD })
public @interface ExcelIndicator {

	int excelPosition() default -1;
	/**
	 * column name
	 */
	String label() default "";
}
