package com.catalog.core.api.dto;

import lombok.Getter;
import lombok.Setter;

/**
 * 
 */
@Setter
@Getter
public class PaginationInfoDTO {

	/**
	 * 
	 * Maximum rows per page.
	 */
	private int pageSize;

	/**
	 * 
	 * Total rows
	 */
	private int totalRows;

	/**
	 * 
	 * Number of total response pages.
	 */
	private int totalPages;

	/**
	 * The current page of the response.
	 *
	 * IMPORTANT: one-based index (possible value is: 1, 2, 3,....)
	 */
	private int currentPage;

	/**
	 * Support infinite scrolling
	 *
	 * true if there is more pages, false if this is the last page.
	 */
	private boolean hasMorePage;
}
