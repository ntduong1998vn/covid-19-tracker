package com.catalog.core.extension.cxmlextension.structure;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CXMLFrom {
    List<CXMlCredential> credentials = new ArrayList<>();
}
