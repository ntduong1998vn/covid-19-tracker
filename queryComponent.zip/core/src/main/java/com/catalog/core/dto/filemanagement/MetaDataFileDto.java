package com.catalog.core.dto.filemanagement;

import lombok.Data;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

@Data
public class MetaDataFileDto {
    @NotEmpty
    private String filePath;
    @NotEmpty
    private String fileName;
    @NotEmpty
    private String mimeType;
    @NotNull
    @Min(value = 1)
    private Long size;
    @Min(value = 1)
    @Max(value = 2)
    private int uploadType;
}
