package com.catalog.core.api.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * 
 */
@Data
@NoArgsConstructor
public abstract class BaseSearchDTO {

	/**
	 * Maximum rows per page.
	 */
	private int pageSize;

	/**
	 * The page number of the request.
	 * 
	 * IMPORTANT: zero-based index
	 */
	private int pageNum;

	/**
	 * 
	 */
	private List<SortDTO> sorts;

}
