package com.catalog.core.api;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 
 * Convert DTO to Entity and reverse
 *
 */
@Component
public class GenericConverter {

	/**
	 * 
	 */
	@Autowired
	protected ModelMapper modelMapper;

	/**
	 * 
	 * @param <Entity>
	 * @param <DTO>
	 * @param entity
	 * @param dtoClass
	 * @return
	 */
	public <Entity, DTO> DTO toDTO(Entity entity, Class<DTO> dtoClass) {

		DTO dto = modelMapper.map(entity, dtoClass);

		return dto;
	}

	/**
	 * 
	 * @param <Entity>
	 * @param <DTO>
	 * @param dto
	 * @param entityClass
	 * @return
	 */
	public <Entity, DTO> Entity toEntity(DTO dto, Class<Entity> entityClass) {
		Entity entity = modelMapper.map(dto, entityClass);
		return entity;
	}

	/**
	 * 
	 * @param <Entity>
	 * @param <DTO>
	 * @param entityList
	 * @param dtoClass
	 * @return
	 */
	public <Entity, DTO> List<DTO> toDTO(final List<Entity> entityList, Class<DTO> dtoClass) {
		return entityList.stream().filter(Objects::nonNull).map(entity -> toDTO(entity, dtoClass))
				.collect(Collectors.toList());
	}

	/**
	 * 
	 * @param <Entity>
	 * @param <DTO>
	 * @param dtoList
	 * @param entityClass
	 * @return
	 */
	public <Entity, DTO> List<Entity> toEntity(final List<DTO> dtoList, Class<Entity> entityClass) {
		return dtoList.stream().filter(Objects::nonNull).map(dto -> toEntity(dto, entityClass))
				.collect(Collectors.toList());
	}

}
