package com.catalog.core.dto;

import lombok.Data;

@Data
public class CSVExportConfig {
    private boolean isShowHeader = true;
    private String FieldDelimiter = ",";
    private String EncodeMode = "auto";
}
