package com.catalog.core.constant;

public class S3Const {
    //TODO move ROOT_FOLDER to config env file;
    public static final String ROOT_FOLDER = "uat";

    public static final String TYPE_IMG = "/img";
    public static final String TYPE_FILE = "/file";
    public static final String TYPE_LOG = "/log";
    public static final String TYPE_EXCEL = "/excel";
    public static final String TYPE_ZIP = "/zip";

    public static final String CATALOG_FOLDER = "/catalog";
    public static final String COMPANY_GROUP_FOLDER = "/companyGroup";
    public static final String COMPANY_FOLDER = "/company";
    public static final String GENRE_FOLDER = "/genre";
    public static final String PRODUCT_FOLDER = "/product";
    public static final String SUPPLIER_PUBLIC_FOLDER = "/supplierPublic";
    public static final String WK_PRODUCT_FOLDER = "/wk_product";
    public static final String CATALOG_NOTICE_FOLDER = "/catalogNotice";
    public static final String WK_TIMER_TASK_ERROR_FOLDER = "/wkTimerTaskError";
    //Log file error when uploading image product/postage/price
    public static final String LOG_FILE_FOLDER = "/log-error";

    public static final String FOLDER_DELIMITER = "/";
    public static final String ALL = "all";
    public static final String FILE = "file";
    public static final String FOLDER = "folder";
}
