package com.catalog.core.dto.buyermastercommon;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Approve Setting Excel Dto
 *
 * @author Create by DuyPHA on 2019/07/25 at 04:32 PM
 */
@Data
@NoArgsConstructor
public class ApproveSettingExcelDto {

    /**
     * 企業グループコード
     */
    private String companyGroupCode;

    /**
     * 承認設定コード
     */
    private String approveSettingCode;

    /**
     * 承認設定名
     */
    private String approveSettingDescription;

    /**
     * ルールセット名
     */
    private String ruleSetName;

    /**
     * ルール名
     */
    private String ruleName;

    /**
     * AND/OR
     */
    private String conditionAndOr;

    /**
     * 条件
     */
    private String conditions;

    /**
     * 次のルールセット
     */
    private String nextRuleSetName;

    /**
     * 段階1
     * 承認組織
     */
    private String orgType1;

    /**
     * 段階1
     * 組織コード
     */
    private String orgCode1;

    /**
     * 段階1
     * 上位含む
     */
    private String orgUpper1;

    /**
     * 段階1
     * 承認者
     */
    private String levelType1;

    /**
     * 段階1
     * 承認レベル
     */
    private String level1;

    /**
     * 段階2
     * 承認組織
     */
    private String orgType2;

    /**
     * 段階2
     * 組織コード
     */
    private String orgCode2;

    /**
     * 段階2
     * 上位含む
     */
    private String orgUpper2;

    /**
     * 段階2
     * 承認者
     */
    private String levelType2;

    /**
     * 段階2
     * 承認レベル
     */
    private String level2;

    /**
     * 段階3
     * 承認組織
     */
    private String orgType3;

    /**
     * 段階3
     * 組織コード
     */
    private String orgCode3;

    /**
     * 段階3
     * 上位含む
     */
    private String orgUpper3;

    /**
     * 段階3
     * 承認者
     */
    private String levelType3;

    /**
     * 段階3
     * 承認レベル
     */
    private String level3;

    /**
     * 段階4
     * 承認組織
     */
    private String orgType4;

    /**
     * 段階4
     * 組織コード
     */
    private String orgCode4;

    /**
     * 段階1
     * 上位含む
     */
    private String orgUpper4;

    /**
     * 段階1
     * 承認者
     */
    private String levelType4;

    /**
     * 段階1
     * 承認レベル
     */
    private String level4;

    /**
     * 段階5
     * 承認組織
     */
    private String orgType5;

    /**
     * 段階5
     * 組織コード
     */
    private String orgCode5;

    /**
     * 段階5
     * 上位含む
     */
    private String orgUpper5;

    /**
     * 段階5
     * 承認者
     */
    private String levelType5;

    /**
     * 段階5
     * 承認レベル
     */
    private String level5;
}
