/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/16
 */
package com.catalog.core.dto.datamapping;

import lombok.Data;

import java.io.Serializable;

@Data
public class BodyDataFileDto implements Serializable {

    private Object dataId;

    private String dataType;

}
