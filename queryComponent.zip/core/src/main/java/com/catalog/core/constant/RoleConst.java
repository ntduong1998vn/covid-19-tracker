package com.catalog.core.constant;

public class RoleConst {

    public static final long REGISTERED = 1;
    public static final long CATALOG_ADMIN = 2;
    public static final long CATALOG_APPROVAL = 3;
    public static final long MASTER_ADMIN = 4;
    public static final long CATALOG_PRODUCT_APPROVAL = 5;
    public static final long COMPANY_GROUP_ADMIN = 6;
    public static final long ORDER_MANAGER = 7;
    public static final long SEARCH_PRODUCT = 8;
    public static final long GROUP_CATALOG_ADMIN = 9;

    public enum RoleNames {
        /**
         *
         */
        COMPANY_GROUP_ADMIN("企業管理"),
        MASTER_ADMIN("マスタ管理"),
        CATALOG_ADMIN("カタログ管理"),
        CATALOG_APPROVAL("カタログ承認（価格）"),
        CATALOG_PRODUCT_APPROVAL("カタログ承認（商品）"),
        GROUP_CATALOG_ADMIN("グループカタログ管理"),
        SEARCH_PRODUCT("商品検索"),
        ORDER_MANAGER("受注担当"),
        CATALOG_APPROVAL_2("カタログ承認");



        private final String name;
        private RoleNames(final String name) {
            this.name = name;
        }

        public String getRoleName() {
            return name;
        }
    }
}
