package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class CXMlCredential {
    @JacksonXmlProperty(isAttribute=true)
    String domain;
    @JsonProperty(value = "Identity")
    String identity;
    @JsonProperty(value = "SharedSecret")
    String sharedSecret;
}
