package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
public class CXMLItemInDetail {
    @JsonProperty(value = "UnitPrice")
    private CXMLMoney unitPrice = new CXMLMoney();
    @JsonProperty(value = "UnitOfMeasure")
    private String unitOfMeasure;
    @JsonIgnore
    private String lang;
    @JsonIgnore
    private String shortName;
    @JsonIgnore
    private String remarks;
    @JsonProperty(value = "ManufacturerPartID")
    private String manufacturerPartID;
    @JsonIgnore
    private String manufacturerName;
    @JsonProperty(value = "LeadTime")
    private Integer leadTime;
    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "Extrinsic")
    private List<CXMLExtrinsic> extrinsicList = new ArrayList<>();
    private List<CXMLClassification> classificationList = new ArrayList<>();

    @JsonProperty(value = "Description")
    private CXMLDecriptionItemIn description = new CXMLDecriptionItemIn(lang, shortName, remarks);

    @JsonProperty(value = "ManufacturerName")
    private CXMLManufacturerName manufacturer = new CXMLManufacturerName(lang, manufacturerName);

}
