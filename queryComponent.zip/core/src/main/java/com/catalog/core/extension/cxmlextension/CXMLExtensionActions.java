package com.catalog.core.extension.cxmlextension;

import com.catalog.core.extension.cxmlextension.structure.OrderInputRequestcXML;
import com.catalog.core.extension.cxmlextension.structure.OrderInputResponsecXML;
import com.catalog.core.extension.cxmlextension.structure.PunchOutOrderMessage;
import com.catalog.core.util.CommonCoreUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;

import java.io.IOException;
import java.util.Map;

public class CXMLExtensionActions {

    private static final String C_XML = "cXML";

    private CXMLExtensionActions(){

    }

    public static CXMLFromQueryResult getCXMLFromQueryString(Map<String, String[]> params){

        CXMLFromQueryResult result = new CXMLFromQueryResult();
        if (params.containsKey(C_XML)) {
            result.setCXML(params.get(C_XML)[0]);
            return result;
        }
        return result;
    }

    public static PunchOutOrderMessage punchOutOrderMessageDeserialize(String xml) {
        return new PunchOutOrderMessage();
    }

    @Data
    public static class CXMLFromQueryResult {
        String cXML = "";
        String cXMLURLEncoded = "";
        String cXMLBase64 = "";
    }

    public static String orderInputRequestSerialize(OrderInputRequestcXML record){
        ObjectMapper objectMapper = CommonCoreUtils.commonObjectMapper();
        String s = "";

        try {
            s = objectMapper.writeValueAsString(record);
        }
        catch (JsonProcessingException e) {
            e.printStackTrace();
            return "";
        }

        return s;
    }

    public static String orderInputResponseSerialize(OrderInputResponsecXML record){
        String result = "";
        ObjectMapper objectMapper = CommonCoreUtils.commonObjectMapper();
        try {
            result = objectMapper.writeValueAsString(record);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            return result;
        }
        return result;
    }

    public static OrderInputResponsecXML orderInputResponseDeserialize(String xml){
        ObjectMapper objectMapper = CommonCoreUtils.commonObjectMapper();
        OrderInputResponsecXML result;

        try {
            result = objectMapper.readValue(xml, OrderInputResponsecXML.class);
        }
        catch (IOException e) {
            e.printStackTrace();
            result = new OrderInputResponsecXML();
        }

        return result;
    }

    /**
     * MaskAPIData
     *
     * cXML/RES APIに含まれるパスワード、認証情報をマスキング
     *
     * @param input
     * @return
     * @author ThienPG
     */
    public static String maskAPIData(String input) {
        String output = "";
        //TODO

        return output;
    }


}
