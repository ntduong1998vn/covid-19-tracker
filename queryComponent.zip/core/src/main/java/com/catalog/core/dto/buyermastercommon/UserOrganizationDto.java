/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 *
 * */
package com.catalog.core.dto.buyermastercommon;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@RequiredArgsConstructor
public class UserOrganizationDto implements Serializable {

    private String code;

    private String userCode;

    private String userDisplayCode;

    private String userName;

    private String organizationCode;

    private String organizationDisplayCode;

    private String organizationName;

    private String companyPositionCode;

    private String companyPositionDisplayCode;

    private String companyPositionName;

    private String email;

}
