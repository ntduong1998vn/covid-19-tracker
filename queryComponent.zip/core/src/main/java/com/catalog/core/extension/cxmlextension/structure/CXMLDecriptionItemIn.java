package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlText;
import lombok.Data;

@Data
public class CXMLDecriptionItemIn {
    @JacksonXmlProperty(isAttribute=true, localName="xml:lang")
    private String lang;
    @JsonProperty(value = "ShortName")
    private String shortName;
    @JacksonXmlText
    private String remarks;

    public CXMLDecriptionItemIn(String lang, String shortName, String remarks) {
        this.lang = lang;
        this.shortName = shortName;
        this.remarks = remarks;
    }
}
