package com.catalog.core.api;

import com.catalog.core.api.dto.RestResponseDTO;
import org.springframework.beans.TypeMismatchException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * 
 * 
 */
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

	/**
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public ResponseEntity<Object> handleTypeMismatch(TypeMismatchException e, HttpHeaders headers,
		HttpStatus status,
		WebRequest request) {

		logger.error("TypeMismatchException", e);

		ResponseEntity<?> obj = ResponseHelper
				.responseException("Type mismatch when trying to set a bean property " + e.getPropertyName(), e);

		return (ResponseEntity<Object>) obj;
	}

	/**
	 * 
	 * @param e
	 * @param request
	 * @return
	 */
	@ExceptionHandler(value = { IllegalArgumentException.class, IllegalStateException.class })
	protected ResponseEntity<RestResponseDTO<Object>> handleConflict(RuntimeException e, WebRequest request) {

		return ResponseHelper.responseException(e);
	}

	/**
	 * 
	 * @param e
	 * @param request
	 * @return
	 */
	@ExceptionHandler(value = { Exception.class })
	protected ResponseEntity<RestResponseDTO<Object>> handleException(RuntimeException e, WebRequest request) {

		e.printStackTrace();

		return ResponseHelper.responseException(e);
	}
}