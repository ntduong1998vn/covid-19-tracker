package com.catalog.core.api.dto;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 
 */
@Data
@NoArgsConstructor
public class AppInfoDTO {

	/**
	 * 
	 */
	private String applicationName;

	/**
	 * 
	 */
	private String localBaseUrl;

	/**
	 * 
	 */
	private String baseUrl;

	/**
	 * 
	 */
	private String[] activeProfiles;
}
