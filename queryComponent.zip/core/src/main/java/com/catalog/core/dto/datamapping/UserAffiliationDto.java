/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/20
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class UserAffiliationDto implements Serializable {

    /**
     * 社員ID
     **/
    @ExcelIndicator(excelPosition = 0)
    private String userCd;
    /**
     * 従業員番号
     **/
    @ExcelIndicator(excelPosition = 1)
    private String employeeCd;
    /**
     * ポジションID
     **/
    @ExcelIndicator(excelPosition = 2)
    private String positionCd;

    /**
     * 組織コード
     **/
    @ExcelIndicator(excelPosition = 3)
    private String organizationDisplayCode;

    /**
     * 有効開始日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 4)
    private String effectiveStartDate;
    /**
     * 有効終了日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 5)
    private String effectiveEndDate;

    /**
     * 本務兼務区分
     **/
    @ExcelIndicator(excelPosition = 6)
    private String assignCategory;
    /**
     * ヘッドカウント区分
     **/
    @ExcelIndicator(excelPosition = 7)
    private String headCountCategory;
    /**
     * 異動タイプ
     **/
    @ExcelIndicator(excelPosition = 8)
    private String transferCategory;
    /**
     * 兼務連番
     **/
    @ExcelIndicator(excelPosition = 9)
    private String addPostNo;
    /**
     * 参照ポジションID
     **/
    @ExcelIndicator(excelPosition = 10)
    private String refPositionId;
    /**
     * 在籍区分ステータス
     **/
    @ExcelIndicator(excelPosition = 11)
    private String employmentStatus;
    /**
     * 原籍会社
     **/
    @ExcelIndicator(excelPosition = 12)
    private String companyDisplayCode;
    /**
     * 雇用会社
     **/
    @ExcelIndicator(excelPosition = 13)
    private String endCompanyDisplayCode;
    /**
     * 勤務地
     **/
    @ExcelIndicator(excelPosition = 14)
    private String businessPlace;
    /**
     * 勤務地（ローカル）
     **/
    @ExcelIndicator(excelPosition = 15)
    private String businessPlaceLocal;
    /**
     * 従業員区分（ローカル）
     **/
    @ExcelIndicator(excelPosition = 16)
    private String employeeGroupLocal;
    /**
     * 権限グループコード
     **/
    @ExcelIndicator(excelPosition = 17)
    private String authorityGroupCode;
    /**
     * approvalLevelOrder
     **/
    @ExcelIndicator(excelPosition = 18)
    private String approvalLevelOrder;

    @ExcelIndicator(excelPosition = 19)
    private String companyGroupDisplayCode;
}
