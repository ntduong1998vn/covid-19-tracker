/**
 *
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class AccountTitleDto implements Serializable {


    @ExcelIndicator(excelPosition = 0)
    private String companyDisplayCode;

    @ExcelIndicator(excelPosition = 1)
    private String accountTitleDisplayCode;

    @ExcelIndicator(excelPosition = 2)
    private String glAccountingTextShort;

    @ExcelIndicator(excelPosition = 3)
    private String glAccountingTextLong;

    @ExcelIndicator(excelPosition = 4)
    private String postingBlock;

    @ExcelIndicator(excelPosition = 5)
    private String balanceSheetAccounting;

    @ExcelIndicator(excelPosition = 6)
    private String companyGroupDisplayCode;

}
