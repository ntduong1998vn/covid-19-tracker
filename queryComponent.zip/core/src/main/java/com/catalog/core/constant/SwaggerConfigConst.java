package com.catalog.core.constant;

/**
 * Description for it
 *
 * @author: phongnguyen ON 24/4/20
 */
public class SwaggerConfigConst {
    public static final String MAL_API_GROUP_NAME = "MallAPISwaggerConfigUI";
    public static final String MALL_GROUP_NAME = "MallSwaggerConfigUI";
    public static final String MASTER_GROUP_NAME = "MasterSwaggerConfigUI";
    public static final String SUPPLIER_GROUP_NAME = "SupplierSwaggerConfigUI";
    public static final String AUTH_GROUP_NAME = "AuthSwaggerConfigUI";
    public static final String PRODUCT_INDEX_GROUP_NAME = "ProductIndexSwaggerConfigUI";
    public static final String BATCH_GROUP_NAME = "BatchSwaggerConfigUI";
}
