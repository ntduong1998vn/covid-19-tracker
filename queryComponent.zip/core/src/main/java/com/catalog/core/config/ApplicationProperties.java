package com.catalog.core.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Service;

@Service
@ConfigurationProperties(prefix = "application", ignoreUnknownFields = false)
@PropertySource("application-config.properties")
public class ApplicationProperties {

	private final FileStorage fileStorage = new FileStorage();

	private final AmazonStorageFileS3 amazonStorage = new AmazonStorageFileS3();
	public final MailTemplateConfig mailTemplateConfig = new MailTemplateConfig();

	public FileStorage getFileStorage() {
		return fileStorage;
	}

	public AmazonStorageFileS3 getAmazonStorage() {
		return amazonStorage;
	}

	public MailTemplateConfig getMailTemplateConfig() {
		return mailTemplateConfig;
	}

	public class MailTemplateConfig {
		private String path;
		private String refix;
		private String extendsion;

		public String getPath() {
			return path;
		}

		public String getRefix() {
			return refix;
		}

		public void setPath(String path) {
			this.path = path;
		}

		public void setRefix(String refix) {
			this.refix = refix;
		}

		public String getExtendsion() {
			return extendsion;
		}

		public void setExtendsion(String extendsion) {
			this.extendsion = extendsion;
		}
	}


	public static class FileStorage {

		private String storeLocation;
		private String uploadStoreLocation;
		private String downloadStoreLocation;
		private String tmpStoreLocation;

		public String getStoreLocation() {
			return storeLocation;
		}

		public void setStoreLocation(String storeLocation) {
			this.storeLocation = storeLocation;
		}

		public String getUploadStoreLocation() {
			return uploadStoreLocation;
		}

		public void setUploadStoreLocation(String uploadStoreLocation) {
			this.uploadStoreLocation = uploadStoreLocation;
		}

		public String getDownloadStoreLocation() {
			return downloadStoreLocation;
		}

		public void setDownloadStoreLocation(String downloadStoreLocation) {
			this.downloadStoreLocation = downloadStoreLocation;
		}

		public String getTmpStoreLocation() {
			return tmpStoreLocation;
		}

		public void setTmpStoreLocation(String tmpStoreLocation) {
			this.tmpStoreLocation = tmpStoreLocation;
		}

		@Override
		public String toString() {
			return storeLocation;
		}

	}

	public static class AmazonStorageFileS3 {

		private String endpointUrl;
		private String accessKey;
		private String secretKey;
		private String bucketName;
		private String region;

		public AmazonStorageFileS3() {
			super();
		}

		public AmazonStorageFileS3(String endpointUrl, String accessKey, String secretKey, String bucketName,
				String region) {
			super();
			this.endpointUrl = endpointUrl;
			this.accessKey = accessKey;
			this.secretKey = secretKey;
			this.bucketName = bucketName;
			this.region = region;
		}

		public String getEndpointUrl() {
			return endpointUrl;
		}

		public void setEndpointUrl(String endpointUrl) {
			this.endpointUrl = endpointUrl;
		}

		public String getAccessKey() {
			return accessKey;
		}

		public void setAccessKey(String accessKey) {
			this.accessKey = accessKey;
		}

		public String getSecretKey() {
			return secretKey;
		}

		public void setSecretKey(String secretKey) {
			this.secretKey = secretKey;
		}

		public String getBucketName() {
			return bucketName;
		}

		public void setBucketName(String bucketName) {
			this.bucketName = bucketName;
		}

		public String getRegion() {
			return region;
		}

		public void setRegion(String region) {
			this.region = region;
		}

		@Override
		public String toString() {
			return "AmazonStorageFileS3 [endpointUrl=" + endpointUrl + ", accessKey=" + accessKey + ", secretKey="
					+ secretKey + ", bucketName=" + bucketName + ", region=" + region + "]";
		}

	}


	@Override
	public String toString() {
		return fileStorage + "";
	}

}
