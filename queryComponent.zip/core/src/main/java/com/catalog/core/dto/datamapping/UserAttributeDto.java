/**
 * Created by Bizhw & EPS.
 * User: TuanNH
 * Created: 2019/08/20
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class UserAttributeDto implements Serializable {

    /**
     * 社員ID
     **/
    @ExcelIndicator(excelPosition = 0)
    private String userCd;
    /**
     * 従業員番号
     **/
    @ExcelIndicator(excelPosition = 1)
    private String employeeCd;
    /**
     * 言語コード
     **/
    @ExcelIndicator(excelPosition = 2)
    private String languageCd;
    /**
     * 有効開始日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 3)
    private String effectiveStartDate;
    /**
     * 有効終了日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 4)
    private String effectiveEndDate;
    /**
     * ビジネスネーム（英）
     **/
    @ExcelIndicator(excelPosition = 5)
    private String businessNameEn;
    /**
     * ビジネスネーム
     **/
    @ExcelIndicator(excelPosition = 6)
    private String businessName;
    /**
     * ファーストネーム（英）
     **/
    @ExcelIndicator(excelPosition = 7)
    private String firstNameEn;
    /**
     * ミドルネーム（英）
     **/
    @ExcelIndicator(excelPosition = 8)
    private String middleNameEn;
    /**
     * ラストネーム（英）
     **/
    @ExcelIndicator(excelPosition = 9)
    private String lastNameEn;
    /**
     * ニックネーム（英）
     **/
    @ExcelIndicator(excelPosition = 10)
    private String nickNameEn;
    /**
     * サフィックス（英）
     **/
    @ExcelIndicator(excelPosition = 11)
    private String suffixNameEn;
    /**
     * ファーストネーム
     **/
    @ExcelIndicator(excelPosition = 12)
    private String firstName;
    /**
     * ミドルネーム
     **/
    @ExcelIndicator(excelPosition = 13)
    private String middleName;
    /**
     * ラストネーム
     **/
    @ExcelIndicator(excelPosition = 14)
    private String lastName;
    /**
     * ニックネーム
     **/
    @ExcelIndicator(excelPosition = 15)
    private String nickName;
    /**
     * サフィックス
     **/
    @ExcelIndicator(excelPosition = 16)
    private String suffixName;
    /**
     * 生年月日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 17)
    private String birthDate;
    /**
     * 性別区分
     **/
    @ExcelIndicator(excelPosition = 18)
    private String genderCd;

    @ExcelIndicator(excelPosition = 19)
    private String companyGroupDisplayCode;
}
