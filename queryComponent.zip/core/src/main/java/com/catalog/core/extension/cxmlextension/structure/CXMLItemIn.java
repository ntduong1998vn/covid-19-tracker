package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import lombok.Data;

@Data
public class CXMLItemIn {
    @JacksonXmlProperty(isAttribute=true)
    Double quantity;
    @JsonProperty(value = "ItemDetail")
    CXMLItemInDetail itemDetail = new CXMLItemInDetail();
    @JsonProperty(value = "ItemID")
    CXMLItemInID itemID = new CXMLItemInID();

    @JsonProperty(value = "Tax")
    CXMLTax cxmlTax = new CXMLTax();
    @Data
    public static class CXMLTax {
        @JsonProperty(value = "Money")
        private Integer amount = 0;
        @JsonProperty(value = "Description")
        private String description ;
    }
}
