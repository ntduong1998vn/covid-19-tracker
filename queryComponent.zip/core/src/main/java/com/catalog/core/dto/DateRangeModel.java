package com.catalog.core.dto;

import java.time.Instant;

public class DateRangeModel {

	/** */
	private Instant minDate;

	/** */
	private Instant maxDate;

	public Instant getMinDate() {
		return minDate;
	}

	public void setMinDate(Instant minDate) {
		this.minDate = minDate;
	}

	public Instant getMaxDate() {
		return maxDate;
	}

	public void setMaxDate(Instant maxDate) {
		this.maxDate = maxDate;
	}
}
