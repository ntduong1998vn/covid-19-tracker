package com.catalog.core.api.dto;

public class SortDTO {

}
