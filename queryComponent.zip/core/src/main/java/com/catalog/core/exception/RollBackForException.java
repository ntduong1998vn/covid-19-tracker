package com.catalog.core.exception;

public class RollBackForException extends Exception {

    public RollBackForException(String msg){
        super(msg);
    }
}
