package com.catalog.core.controller;

import com.catalog.core.exception.resolver.ExceptionResolver;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BaseController extends ExceptionResolver {
}
