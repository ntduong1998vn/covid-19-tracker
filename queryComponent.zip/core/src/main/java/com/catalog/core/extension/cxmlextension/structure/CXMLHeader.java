package com.catalog.core.extension.cxmlextension.structure;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CXMLHeader {
    private CredentialFromRecord from = new CredentialFromRecord();
    private CredentialToRecord to = new CredentialToRecord();
    private CredentialSenderRecord sender = new CredentialSenderRecord();


    @Data
    public static class CredentialFromRecord {
        @JsonProperty(value = "Credential")
        private CXMlCredential credential = new CXMlCredential();
        private CXMLFrom from = new CXMLFrom();
    }

    @Data
    public static class CredentialToRecord {
        @JsonProperty(value = "Credential")
        private CXMlCredential credential = new CXMlCredential();
        private CXMLTo to = new CXMLTo();
    }

    @Data
    public static class CredentialSenderRecord {
        @JsonProperty(value = "Credential")
        private CXMlCredential credential = new CXMlCredential();
        @JsonIgnore
        private CXMLSender sender = new CXMLSender();
    }
}
