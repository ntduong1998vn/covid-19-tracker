package com.catalog.core.constant;

/**
 * ==> NOTE: CommonCharactersConst stores Characters is shared between Services
 */
public class CommonCharactersConst {

    public final static String BASE_API_URL = "/v1/api";
    // ***** Date Time - Zone ******* //
    public final static String DATE_FORMAT_SUPPORT_01 = "\\d{4}/\\d{2}/\\d{2}";

    public final static String DATE_FORMAT_SUPPORT_02 = "\\d{4}\\d{2}\\d{2}";

    public static final String EXIST_SLASH_DATE_REGEX = "^((2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26])))/02/29)$" +
            "|^(((19|2[0-9])[0-9]{2})/02/(0[1-9]|1[0-9]|2[0-8]))$|^(((19|2[0-9])[0-9]{2})/(0[13578]|10|12)/(0[1-9]|[12][0-9]|3[01]))$" +
            "|^(((19|2[0-9])[0-9]{2})/(0[469]|11)/(0[1-9]|[12][0-9]|30))$";

    public static final String EXIST_DASH_DATE_REGEX = "^((2000|2400|2800|(19|2[0-9](0[48]|[2468][048]|[13579][26])))-02-29)$" +
            "|^(((19|2[0-9])[0-9]{2})-02-(0[1-9]|1[0-9]|2[0-8]))$|^(((19|2[0-9])[0-9]{2})-(0[13578]|10|12)-(0[1-9]|[12][0-9]|3[01]))$" +
            "|^(((19|2[0-9])[0-9]{2})-(0[469]|11)-(0[1-9]|[12][0-9]|30))$";

    public static final String SLASH_DATE_MISS_SECOND_REGEX = "^\\d\\d\\d\\d\\/(0?[1-9]|1[0-2])\\/(0?[1-9]|[12][0-9]|3[01]) (00|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9])$";

    public static final String DASH_DATE_MISS_SECOND_REGEX = "^\\d\\d\\d\\d-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]) (00|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9])$";

    // ***** Redis Key ******* //

    public static final String USER_KEY = "user";

    /******************** Regex ********************/
    public static final String ZIPCODE_REGEX = "^[0-9-]*$";
    public static final String EMAIL_REGEX = "^$|^\\s+$|^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
    public static final String EMAIL_OPTION_DOMAIN_REGEX = "^$|^\\s+$|^[\\w-_\\.+]*[\\w-_\\.]\\@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-\\.])+))([a-zA-Z]{2,4}|[0-9]{1,3})$";
    public static final String MULTI_EMAIL_REGEX = "^(([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)(\\s*,\\s*|\\s*$))*$";
    public static final String MULTI_EMAIL_OPTION_DOMAIN_REGEX = "^(([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-\\.])+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)(\\s*,\\s*|\\s*$))*$";
    public static final String TEL_REGEX = "^$|^\\s+$|^[0-9-]*$";
    public static final String UUID_REGEX = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";
    public static final String BCRYPT_REGEX = "^\\$2[ayb]\\$.{56}$";
    public static final String POSITIVE_NUMBER_REGEX = "^(0|[1-9][0-9]*)$";

    /********************** Other ******************************/
    public static final String DEFAULT_CURRENCY_VALUE = "円";
}
