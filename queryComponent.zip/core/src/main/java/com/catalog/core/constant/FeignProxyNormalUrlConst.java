/*
 * Created by Bizhw & EPS.
 * User: ThaiHV
 *
 */

package com.catalog.core.constant;

/**
 * ==> NOTE: FeignProxyNormalUrlConst stores normal URL, BUT [OAUTH / MASTER-COMMON / BUYER-MASTER-COMMON] URL
 */
public class FeignProxyNormalUrlConst {


    /** ==== Shared API URL (BUYER-ORDER Service) ==== --[START]-- **/
    public static final String GET_SUPPLIER_CATALOG_EMAIL = "/get-supplier-catalog-email";
    public static final String GET_PURCHASER_INFO = "/get-purchaser-info";
    public static final String DELETE_TRASH_CM_CHECKOUT = "/delete-trash-cm-checkout";
    /** ==== Shared API URL (BUYER-ORDER Service) ==== --[END]-- **/



    /** ==== Shared API URL (SUPPLIER Service) ==== --[START]-- **/

    /** ==== Shared API URL (SUPPLIER Service) ==== --[END]-- **/



    /** ==== Shared API URL (MASTER-COMMON Service) ==== --[START]-- **/
    public static final String GET_DELETED_PASSWORD_RULE = "/get-deleted-password-rule";
    public static final String GET_DELETED_ROLE = "/get-deleted-role";
    /** ==== Shared API URL (MASTER-COMMON Service) ==== --[END]-- **/



    /** ==== Shared API URL (MAIL-S3 Service) ==== --[START]-- **/

    /** ==== Shared API URL (MAIL-S3 Service) ==== --[END]-- **/



    /** ==== Shared API URL (DATA-MAPPING features) ==== --[START]-- **/

    /** ==== Shared API URL (DATA-MAPPING features) ==== --[END]-- **/



    /** ==== Shared API URL (WORK-FLOW features) ==== --[START]-- **/

    /** ==== Shared API URL (WORK-FLOW features) ==== --[END]-- **/

    /** ==== Shared API URL (FILE Service) ==== --[START]-- **/

    public static final String FILE_DELETE_ACTION = "/delete";

    /** ==== Shared API URL (FILE Service) ==== --[END]-- **/

}
