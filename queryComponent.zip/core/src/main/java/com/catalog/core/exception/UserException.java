package com.catalog.core.exception;

import org.springframework.http.HttpStatus;

public class UserException extends BaseException {
    public UserException(String msg, String code) {
        super(msg, code);
    }

    public UserException(String msg) {
        super(msg, HttpStatus.INTERNAL_SERVER_ERROR.value()+"");
    }
}
