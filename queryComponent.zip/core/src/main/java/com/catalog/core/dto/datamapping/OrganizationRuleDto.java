/**
 * Created by Bizhw & EPS.
 * User: Tannv
 * Created: 2019/08/20
 */
package com.catalog.core.dto.datamapping;

import com.catalog.core.dto.ExcelIndicator;
import lombok.Data;

import java.io.Serializable;

@Data
public class OrganizationRuleDto implements Serializable {

    /**
     * 組織コード
     **/
    @ExcelIndicator(excelPosition = 0)
    private String organizationDisplayCode;
    /**
     * 組織階層From
     **/
    @ExcelIndicator(excelPosition = 1)
    private Integer from;
    /**
     * 組織階層To
     **/
    @ExcelIndicator(excelPosition = 2)
    private Integer to;
    /**
     * 有効開始日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 3)
    private String effectiveStartDate;
    /**
     * 有効終了日 - YYYYMMDD
     **/
    @ExcelIndicator(excelPosition = 4)
    private String effectiveEndDate;

    @ExcelIndicator(excelPosition = 13)
    private String companyGroupDisplayCode;
}
