package com.catalog.core.api;

import com.catalog.core.api.dto.BaseSearchDTO;
import com.catalog.core.api.dto.PaginationInfoDTO;
import com.catalog.core.api.dto.RestResponseDTO;
import com.catalog.core.api.dto.SearchResultDTO;
import com.catalog.core.constant.APIConst;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.web.util.UriComponentsBuilder;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * Utility class for Rest api pagination at server-side
 */
public class PaginationUtil {

	/**
	 * Default page size if NOT set
	 */
	private static final int DEFAULT_PAGE_SIZE = 50;

	/**
	 * Default page num if NOT set
	 */
	private static final int DEFAULT_PAGE_NUM = 1;

	/**
	 * 
	 * @param searchDTO
	 * @param totalRows
	 * 
	 * @return
	 */
	public static Pageable toPageable(final BaseSearchDTO searchDTO, final int totalRows) {

		int pageNum = searchDTO.getPageNum();
		int pageSize = searchDTO.getPageSize();

		if (pageNum < DEFAULT_PAGE_NUM) {
			pageNum = DEFAULT_PAGE_NUM;
		}

		if (pageSize < 1) {
			pageSize = DEFAULT_PAGE_SIZE;
		}

		int totalPage = PaginationUtil.calculateTotalPage(totalRows, pageSize);

		if (pageNum > totalPage) {
			pageNum = totalPage;
		}

		Pageable pageable = PageRequest.of(pageNum, pageSize);

		return pageable;
	}

	/**
	 * 
	 * @param <DTO>
	 * @param searchDTO
	 * @param searchResults
	 * @return
	 */
	public static <DTO> RestResponseDTO<SearchResultDTO<DTO>> pagingResponse(final Pageable pageable, int totalRows,
			List<DTO> searchResults) {

		// Calculate total pages based on total rows and page size
		final int pageSize = pageable.getPageSize();
		final int totalPages = calculateTotalPage(totalRows, pageSize);

		int currentPage = pageable.getPageNumber();

		if (currentPage < DEFAULT_PAGE_NUM) {
			currentPage = DEFAULT_PAGE_NUM;
		}

		// Pagination info DTO
		final PaginationInfoDTO paging = new PaginationInfoDTO();

		paging.setCurrentPage(currentPage);
		paging.setPageSize(pageSize);
		paging.setTotalPages(totalPages);
		paging.setTotalRows(totalRows);

		// Search result DTO
		final SearchResultDTO<DTO> searchResultDTO = new SearchResultDTO<>();
		searchResultDTO.setResults(searchResults);
		searchResultDTO.setPaging(paging);

		// Rest Response DTO
		final RestResponseDTO<SearchResultDTO<DTO>> responseDTO = new RestResponseDTO<>();
		responseDTO.setStatus(APIConst.SUCCESS);
		responseDTO.setData(searchResultDTO);

		return responseDTO;
	}

	/**
	 * Calculate how many pages based on total rows and page size.
	 * 
	 * @param totalRows
	 * @param pageSize
	 * 
	 * @return total pages
	 */
	public static int calculateTotalPage(int totalRows, int pageSize) {

		int totalPages = 0;

		// Calculate how many pages there are
		if (totalRows % pageSize == 0) {
			totalPages = totalRows / pageSize;

		} else {
			totalPages = (totalRows / pageSize) + 1;
		}

		return totalPages;
	}

	/**
	 * 
	 * @param uriBuilder
	 * @param response
	 * @param clazz
	 * @param page
	 * @param totalPages
	 * @param pageSize
	 */
	public static void addLinkHeaderOnPagedResourceRetrieval(final UriComponentsBuilder uriBuilder,
			final HttpServletResponse response, final Class<?> clazz, final int page, final int totalPages,
			final int pageSize) {

		final String resourceName = clazz.getSimpleName().toString().toLowerCase();
		uriBuilder.path("/admin/" + resourceName);

		final StringBuilder linkHeader = new StringBuilder();

		// Build url to the next page
		if (hasNextPage(page, totalPages)) {
			final String uriForNextPage = constructNextPageUri(uriBuilder, page, pageSize);
			linkHeader.append(createLinkHeader(uriForNextPage, "next"));
		}

		// Build url to the prev page
		if (hasPreviousPage(page)) {
			final String uriForPrevPage = constructPrevPageUri(uriBuilder, page, pageSize);
			appendCommaIfNecessary(linkHeader);
			linkHeader.append(createLinkHeader(uriForPrevPage, "prev"));
		}

		// Build url to the first page
		if (hasFirstPage(page)) {
			final String uriForFirstPage = constructFirstPageUri(uriBuilder, pageSize);
			appendCommaIfNecessary(linkHeader);
			linkHeader.append(createLinkHeader(uriForFirstPage, "first"));
		}

		// Build the url to the last page
		if (hasLastPage(page, totalPages)) {
			final String uriForLastPage = constructLastPageUri(uriBuilder, totalPages, pageSize);
			appendCommaIfNecessary(linkHeader);
			linkHeader.append(createLinkHeader(uriForLastPage, "last"));
		}

		// Add to response header
		response.addHeader("Link", linkHeader.toString());
	}

	/**
	 * 
	 * @param uriBuilder
	 * @param page
	 * @param size
	 * @return
	 */
	public static String constructNextPageUri(final UriComponentsBuilder uriBuilder, final int page, final int size) {
		return uriBuilder.replaceQueryParam("page", page + 1).replaceQueryParam("size", size).build().encode()
				.toUriString();
	}

	/**
	 * 
	 * @param uriBuilder
	 * @param page
	 * @param size
	 * @return
	 */
	public static String constructPrevPageUri(final UriComponentsBuilder uriBuilder, final int page, final int size) {
		return uriBuilder.replaceQueryParam("page", page - 1).replaceQueryParam("size", size).build().encode()
				.toUriString();
	}

	/**
	 * 
	 * @param uriBuilder
	 * @param size
	 * @return
	 */
	public static String constructFirstPageUri(final UriComponentsBuilder uriBuilder, final int size) {
		return uriBuilder.replaceQueryParam("page", 0).replaceQueryParam("size", size).build().encode().toUriString();
	}

	/**
	 * 
	 * @param uriBuilder
	 * @param totalPages
	 * @param size
	 * @return
	 */
	public static String constructLastPageUri(final UriComponentsBuilder uriBuilder, final int totalPages,
			final int size) {
		return uriBuilder.replaceQueryParam("page", totalPages).replaceQueryParam("size", size).build().encode()
				.toUriString();
	}

	/**
	 * 
	 * @param page
	 * @param totalPages
	 * @return
	 */
	public static boolean hasNextPage(final int page, final int totalPages) {
		return page < totalPages - 1;
	}

	/**
	 * 
	 * @param page
	 * @return
	 */
	public static boolean hasPreviousPage(final int page) {
		return page > 0;
	}

	/**
	 * 
	 * @param page
	 * @return
	 */
	public static boolean hasFirstPage(final int page) {
		return hasPreviousPage(page);
	}

	/**
	 * 
	 * @param page
	 * @param totalPages
	 * @return
	 */
	public static boolean hasLastPage(final int page, final int totalPages) {
		return totalPages > 1 && hasNextPage(page, totalPages);
	}

	/**
	 * 
	 * @param linkHeader
	 */
	public static void appendCommaIfNecessary(final StringBuilder linkHeader) {
		if (linkHeader.length() > 0) {
			linkHeader.append(", ");
		}
	}

	/**
	 * 
	 * @param uri
	 * @param rel
	 * @return
	 */
	public static String createLinkHeader(final String uri, final String rel) {
		return "<" + uri + ">; rel=\"" + rel + "\"";
	}

}
