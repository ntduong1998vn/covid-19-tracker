package com.catalog.core.dto.filemanagement;

import lombok.Data;

@Data
public class UploadS3Dto {
    private MetaDataFileDto metadata;
    private String metaDataCompanyGroupCode;
    private String metaDataCompanyCode;
    private String metaDataUserCode;

}
